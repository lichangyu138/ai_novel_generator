"""
测试 Token 限制和分段生成
用于验证修复后的章节生成功能
"""

def test_token_calculation():
    """测试 token 和汉字的换算关系"""
    print("=" * 50)
    print("Token 和汉字换算关系测试")
    print("=" * 50)
    
    # 假设 1 汉字 = 2.5 tokens（平均值）
    token_per_char = 2.5
    
    test_cases = [
        (1500, "短章"),
        (2000, "标准短章"),
        (2500, "中等章节"),
        (3000, "标准章节"),
        (4000, "长章"),
        (5000, "长章节"),
    ]
    
    print(f"\n{'字数':<10} {'需要tokens':<15} {'类型':<15}")
    print("-" * 50)
    
    for chars, desc in test_cases:
        tokens_needed = int(chars * token_per_char)
        print(f"{chars:<10} {tokens_needed:<15} {desc:<15}")
    
    print("\n" + "=" * 50)
    print("max_tokens 限制分析")
    print("=" * 50)
    
    max_tokens_options = [4096, 8192, 16384]
    
    print(f"\n{'max_tokens':<15} {'可生成汉字':<20} {'说明':<30}")
    print("-" * 70)
    
    for max_tokens in max_tokens_options:
        min_chars = int(max_tokens / 3)  # 最少（1 token = 3 汉字）
        max_chars = int(max_tokens / 2)  # 最多（1 token = 2 汉字）
        avg_chars = int(max_tokens / 2.5)  # 平均（1 token = 2.5 汉字）
        
        print(f"{max_tokens:<15} {min_chars}-{max_chars} (平均{avg_chars})")
    
    print("\n" + "=" * 50)
    print("分段生成策略")
    print("=" * 50)
    
    target_chars = 5000
    max_tokens_per_call = 4096
    
    print(f"\n目标字数: {target_chars} 字")
    print(f"单次 max_tokens: {max_tokens_per_call}")
    print(f"单次可生成: {int(max_tokens_per_call / 2.5)} 字（平均）")
    
    # 计算需要几段
    chars_per_call = int(max_tokens_per_call / 2.5)
    num_calls = (target_chars + chars_per_call - 1) // chars_per_call
    
    print(f"\n建议分段数: {num_calls} 段")
    print(f"每段目标字数: {target_chars // num_calls} 字")
    
    print("\n分段方案:")
    for i in range(num_calls):
        print(f"  第 {i+1} 段: {target_chars // num_calls} 字 (max_tokens={max_tokens_per_call})")
    
    print(f"\n总计: {num_calls} 次 API 调用，预计生成 {target_chars} 字")


def test_prompt_strategy():
    """测试提示词策略"""
    print("\n" + "=" * 50)
    print("提示词策略建议")
    print("=" * 50)
    
    strategies = [
        {
            "name": "单次生成（不推荐）",
            "max_tokens": 16000,
            "target_chars": 5000,
            "risk": "可能触发 API 限制错误",
            "success_rate": "低"
        },
        {
            "name": "两段生成（推荐）",
            "max_tokens": 4096,
            "target_chars": 2500,
            "risk": "需要处理衔接问题",
            "success_rate": "高"
        },
        {
            "name": "三段生成（保守）",
            "max_tokens": 4096,
            "target_chars": 1700,
            "risk": "API 调用次数多，成本高",
            "success_rate": "很高"
        }
    ]
    
    print(f"\n{'策略':<20} {'max_tokens':<15} {'每段字数':<15} {'成功率':<10}")
    print("-" * 70)
    
    for strategy in strategies:
        print(f"{strategy['name']:<20} {strategy['max_tokens']:<15} {strategy['target_chars']:<15} {strategy['success_rate']:<10}")
        print(f"  风险: {strategy['risk']}")
        print()


if __name__ == "__main__":
    test_token_calculation()
    test_prompt_strategy()
    
    print("\n" + "=" * 50)
    print("测试完成")
    print("=" * 50)
    print("\n建议:")
    print("1. 使用两段生成策略，每段 max_tokens=4096")
    print("2. 每段目标 2500-3000 字")
    print("3. 总计可生成 5000-6000 字")
    print("4. 注意前后段的衔接")
    print("5. 在提示词中明确标注【前半部分】和【后半部分】")

