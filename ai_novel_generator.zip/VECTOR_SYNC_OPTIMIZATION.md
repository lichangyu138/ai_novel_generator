# 向量库同步优化方案

## 已完成的改动

### 1. 数据库字段添加
为以下表添加了向量同步标记字段：
- `characters`
- `worldbuilding_locations`
- `worldbuilding_items`
- `worldbuilding_organizations`

新增字段：
- `vector_synced` (BOOLEAN) - 是否已同步到向量库
- `vector_synced_at` (TIMESTAMP) - 向量同步时间
- `content_hash` (VARCHAR(64)) - 内容哈希值，用于检测变更

### 2. Python 后端 API

#### 新增接口：GET `/api/vector/sync/status/{novel_id}`
获取指定小说的向量同步状态

**响应示例：**
```json
{
  "total": 27,
  "synced": 15,
  "need_sync": 12,
  "items": [
    {
      "source_type": "character",
      "source_id": 1,
      "name": "张三",
      "synced": true,
      "synced_at": "2025-12-24T10:30:00",
      "content_hash": "abc123..."
    }
  ]
}
```

#### 优化接口：POST `/api/vector/sync`
- 自动计算内容哈希
- 同步成功后更新数据库标记
- 支持去重和更新

### 3. 工作流程

```
用户编辑数据 → vector_synced = FALSE
              ↓
用户点击"同步到向量库" → 调用 /api/vector/sync
              ↓
生成 embedding → 更新 Milvus → 标记 vector_synced = TRUE
              ↓
前端显示"已同步"状态
```

## 待完成的前端改动

### 1. Node.js 后端 (server/routers.ts)

添加获取同步状态的 tRPC 路由：

```typescript
// 在 worldbuilding router 中添加
getVectorSyncStatus: protectedProcedure
  .input(z.object({ novelId: z.number() }))
  .query(async ({ ctx, input }) => {
    const pythonApiUrl = process.env.PYTHON_API_URL || 'http://localhost:8000';
    const response = await fetch(
      `${pythonApiUrl}/api/vector/sync/status/${input.novelId}`,
      {
        headers: {
          'X-User-ID': ctx.user.id.toString(),
          'X-Username': ctx.user.username
        }
      }
    );
    
    if (!response.ok) {
      throw new Error('获取同步状态失败');
    }
    
    return await response.json();
  }),
```

### 2. 前端组件

在世界观管理页面添加：

1. **同步状态显示**
   - 总数 / 已同步 / 待同步
   - 每个条目显示同步状态图标

2. **同步按钮**
   - "同步到向量库" 按钮
   - 只同步未同步或已变更的数据
   - 显示同步进度

3. **UI 示例**
```tsx
<div className="sync-status">
  <Badge>
    {syncStatus.synced}/{syncStatus.total} 已同步
  </Badge>
  {syncStatus.need_sync > 0 && (
    <Button onClick={handleSync}>
      同步 {syncStatus.need_sync} 条数据到向量库
    </Button>
  )}
</div>

<Table>
  {items.map(item => (
    <TableRow key={item.id}>
      <TableCell>{item.name}</TableCell>
      <TableCell>
        {item.synced ? (
          <Badge variant="success">已同步</Badge>
        ) : (
          <Badge variant="warning">待同步</Badge>
        )}
      </TableCell>
    </TableRow>
  ))}
</Table>
```

## 优势

1. ✅ **避免重复同步** - 通过数据库标记避免重复生成 embedding
2. ✅ **检测内容变更** - 通过 content_hash 检测内容是否变更
3. ✅ **按需同步** - 只同步未同步或已变更的数据
4. ✅ **状态可视化** - 用户清楚知道哪些数据已同步
5. ✅ **节省成本** - 减少不必要的 embedding API 调用

## 使用说明

1. 用户编辑角色/地点/物品/组织后，该条目标记为"待同步"
2. 点击"同步到向量库"按钮，只同步待同步的数据
3. 同步成功后，条目标记为"已同步"，显示同步时间
4. 再次编辑后，自动标记为"待同步"

## 下一步

请按照上述方案完成前端改动，然后测试完整流程。

