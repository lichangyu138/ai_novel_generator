# 向量库智能同步方案

## 优化目标
- ✅ 避免重复生成 embedding（节省成本和时间）
- ✅ 智能检测内容变更
- ✅ 支持增量更新
- ✅ 显示同步状态

## 实现方案

### 1. 数据库字段
为每个表添加了以下字段：
- `vector_id` (BIGINT) - 向量库中的ID，用于精确更新
- `vector_synced` (BOOLEAN) - 是否已同步
- `vector_synced_at` (TIMESTAMP) - 同步时间
- `content_hash` (VARCHAR) - 内容哈希，用于检测变更

### 2. 智能同步逻辑

```
用户点击"同步" 
  ↓
计算内容哈希
  ↓
对比数据库中的 content_hash
  ↓
├─ 内容未变更 → 跳过（不生成 embedding）
└─ 内容已变更 → 生成 embedding → 更新向量库
                  ↓
              保存 vector_id 和 content_hash
```

### 3. 工作流程

#### 首次同步
1. 生成 embedding
2. 插入 Milvus，获得 vector_id
3. 保存 vector_id 和 content_hash 到数据库
4. 标记 vector_synced = TRUE

#### 内容未变更
1. 计算 content_hash
2. 对比数据库中的 hash
3. 相同 → 跳过，提示"内容未变更，无需同步"

#### 内容已变更
1. 计算新的 content_hash
2. 与数据库对比，发现不同
3. 生成新的 embedding
4. 使用 vector_id 删除旧数据
5. 插入新数据，获得新的 vector_id
6. 更新数据库

### 4. 性能优化

**节省成本：**
- 只对变更的内容生成 embedding
- 避免重复调用 embedding API

**提升速度：**
- 跳过未变更的数据
- 批量处理多个条目

**精确更新：**
- 通过 vector_id 精确定位和更新
- 避免全量删除重建

## 使用示例

### 场景1：首次同步
```
用户编辑"月影宗" → 点击"同步"
→ 生成 embedding（耗时 1-2秒）
→ 保存到向量库，vector_id = 12345
→ 提示"已同步 1 条数据"
```

### 场景2：内容未变更
```
用户再次点击"同步"（内容未改）
→ 对比 hash，发现相同
→ 跳过 embedding 生成
→ 提示"内容未变更，无需同步"（瞬间完成）
```

### 场景3：内容已变更
```
用户修改描述 → 点击"同步"
→ 对比 hash，发现不同
→ 生成新 embedding
→ 删除 vector_id=12345 的旧数据
→ 插入新数据，vector_id = 12346
→ 提示"已同步 1 条数据"
```

## 优势

1. **节省成本** - 避免重复生成 embedding
2. **提升速度** - 跳过未变更的数据
3. **精确更新** - 通过 ID 精确定位
4. **用户友好** - 清晰的状态提示

## 技术细节

### 内容哈希计算
```python
def calculate_content_hash(content: str) -> str:
    return hashlib.sha256(content.encode('utf-8')).hexdigest()
```

### 同步状态判断
```python
# 检查是否需要同步
need_sync = False
if not is_synced:
    need_sync = True  # 从未同步过
elif old_hash != new_hash:
    need_sync = True  # 内容已变更
else:
    need_sync = False  # 内容未变更，跳过
```

### 向量库更新
```python
# 删除旧数据
if vector_id:
    collection.delete(f"id == {vector_id}")

# 插入新数据
new_vector_id = collection.insert(data)

# 更新数据库
UPDATE table SET 
    vector_id = new_vector_id,
    content_hash = new_hash,
    vector_synced = TRUE
```

## 测试建议

1. **首次同步** - 验证 vector_id 正确保存
2. **重复同步** - 验证跳过逻辑
3. **修改后同步** - 验证更新逻辑
4. **批量同步** - 验证性能

## 下一步

- [ ] 添加同步状态图标（已同步/待同步）
- [ ] 添加批量同步按钮（只同步变更的）
- [ ] 添加同步历史记录
- [ ] 添加同步进度条

