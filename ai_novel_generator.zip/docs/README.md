# AI小说生成系统 - 幻写次元

## 项目概述

**幻写次元**是一个基于人工智能的小说创作辅助平台，旨在帮助作者从构思到成稿的全流程创作。系统集成了大语言模型、知识图谱、向量检索等先进技术，提供智能大纲生成、角色设定、章节创作、内容优化等功能。

### 核心特性

| 功能模块 | 描述 |
|---------|------|
| **智能大纲生成** | 基于小说设定自动生成总大纲和细纲，支持AI修改和手动调整 |
| **角色管理** | 完整的人物设定系统，支持性别、关系网络、AI生成描述 |
| **章节创作** | 单章生成模式，支持字数选择、流式输出、AI对话修改 |
| **知识图谱** | 自动构建人物关系图、事件时间线，保证剧情连贯性 |
| **版本管理** | 完整的历史版本记录，支持回溯和对比 |
| **阅读模式** | 沉浸式阅读体验，支持主题切换、字体调节、MD导出 |

### 技术亮点

- **去AI味功能**：通过作家风格模板和文风优化，使生成内容更自然
- **伏笔管理**：自动跟踪和提醒待回收的伏笔，确保剧情完整性
- **AI评论系统**：每章生成后自动分析质量、检查偏差、提出建议

## 系统要求

### 最低配置

- **CPU**: 4核心
- **内存**: 8GB RAM
- **存储**: 50GB 可用空间
- **操作系统**: Ubuntu 20.04+ / macOS 12+ / Windows 10+

### 推荐配置

- **CPU**: 8核心
- **内存**: 16GB RAM
- **存储**: 100GB SSD
- **GPU**: NVIDIA GPU（用于本地模型推理，可选）

### 软件依赖

| 组件 | 版本要求 | 用途 |
|------|---------|------|
| Node.js | 18.0+ | 前端和Node后端运行时 |
| Python | 3.10+ | Python后端运行时 |
| MySQL | 8.0+ | 主数据库 |
| Redis | 7.0+ | 缓存和会话管理 |
| Neo4j | 5.0+ | 知识图谱存储 |
| Milvus | 2.3+ | 向量数据库 |
| Docker | 24.0+ | 容器化部署（可选） |

## 快速开始

### 方式一：Docker部署（推荐）

```bash
# 1. 克隆项目
git clone https://github.com/your-repo/ai_novel_generator.git
cd ai_novel_generator

# 2. 配置环境变量
cp .env.example .env
# 编辑 .env 文件，填写必要的配置

# 3. 启动所有服务
docker-compose up -d

# 4. 初始化数据库
docker exec -i ai_novel_mysql mysql -uroot -proot123456 < scripts/init-mysql.sql

# 5. 访问应用
# 前端: http://localhost:3000
# Python API: http://localhost:8000
# Neo4j: http://localhost:7474
```

### 方式二：本地开发

```bash
# 1. 安装依赖
pnpm install

# 2. 配置数据库
# 确保MySQL、Redis、Neo4j、Milvus已启动
# 执行 scripts/init-mysql.sql 初始化数据库

# 3. 推送数据库Schema
pnpm db:push

# 4. 启动开发服务器
pnpm dev

# 5. 启动Python后端（新终端）
cd python_backend
pip install -r requirements.txt
python main.py
```

## 项目结构

```
ai_novel_generator/
├── client/                    # 前端代码
│   ├── src/
│   │   ├── components/        # 可复用组件
│   │   ├── pages/            # 页面组件
│   │   ├── lib/              # 工具函数
│   │   └── App.tsx           # 路由配置
│   └── public/               # 静态资源
├── server/                    # Node.js后端
│   ├── _core/                # 核心模块
│   ├── db.ts                 # 数据库操作
│   └── routers.ts            # tRPC路由
├── python_backend/            # Python后端
│   ├── app/
│   │   ├── api/              # API路由
│   │   ├── services/         # 业务服务
│   │   │   └── langchain/    # LLM服务
│   │   ├── models/           # 数据模型
│   │   └── config/           # 配置文件
│   └── main.py               # 入口文件
├── drizzle/                   # 数据库Schema
├── scripts/                   # 初始化脚本
├── docs/                      # 文档
└── docker-compose.yml         # Docker配置
```

## 功能模块详解

### 1. 小说管理

创建和管理小说项目，支持自定义类型、风格、世界观设定。

**支持的小说类型**：玄幻、仙侠、武侠、都市、言情、科幻、历史、游戏、竞技、军事等，支持自定义。

**支持的风格**：轻松幽默、严肃正剧、黑暗沉重、温馨治愈、悬疑烧脑、热血激燃等，支持自定义。

### 2. 角色设定

完整的人物管理系统：

- **基本信息**：姓名、性别、角色定位
- **详细设定**：性格、背景、外貌、能力
- **关系网络**：支持建立角色间的各种关系（亲属、朋友、敌人等）
- **AI生成**：一键生成角色描述

### 3. 大纲系统

分层的大纲管理：

- **总大纲**：整体故事框架和主线剧情
- **细纲**：每章约2000字的详细规划，包含：
  - 前文总结
  - 本章剧情发展
  - 人物动态
  - 场景描述
  - 关键事件

### 4. 章节创作

智能章节生成：

- **单章生成**：每次生成一章，确保质量
- **字数控制**：支持1500-5000字选择
- **流式输出**：实时显示生成内容
- **AI对话修改**：通过对话方式调整内容
- **手动编辑**：完全的编辑自由度

### 5. 知识图谱

自动构建和维护：

- **人物关系图**：可视化角色关系网络
- **事件时间线**：按时间顺序展示剧情发展
- **知识库**：自动提取人物、地点、物品、事件信息
- **自动更新**：每章生成后自动同步

### 6. AI评论系统

每章生成后自动分析：

- **质量评分**：综合评估章节质量
- **偏差检查**：与大纲/细纲的一致性分析
- **优缺点分析**：指出亮点和待改进处
- **未来建议**：对后续剧情的建议
- **伏笔标记**：识别和跟踪伏笔

### 7. 阅读与导出

- **阅读模式**：日间/夜间/护眼三种主题
- **字体调节**：大小和行距自定义
- **章节导航**：键盘快捷键支持
- **MD导出**：单章或全书导出

## API文档

### Node.js后端 (tRPC)

主要路由：

| 路由 | 方法 | 描述 |
|------|------|------|
| `novels.list` | Query | 获取小说列表 |
| `novels.get` | Query | 获取小说详情 |
| `novels.create` | Mutation | 创建小说 |
| `novels.update` | Mutation | 更新小说 |
| `chapters.list` | Query | 获取章节列表 |
| `chapters.create` | Mutation | 创建章节 |
| `ai.generateOutline` | Mutation | AI生成大纲 |
| `ai.generateChapter` | Mutation | AI生成章节 |

### Python后端 (FastAPI)

主要端点：

| 端点 | 方法 | 描述 |
|------|------|------|
| `/api/generate/chapter/stream` | POST | 流式生成章节 |
| `/api/generate/outline` | POST | 生成细纲 |
| `/api/knowledge/query` | POST | 查询知识库 |
| `/api/knowledge/sync` | POST | 同步知识库 |
| `/api/config/embedding` | GET/POST | 嵌入模型配置 |
| `/api/config/rerank` | GET/POST | 重排模型配置 |

## 配置说明

详细的环境变量配置请参考 [ENV_CONFIG.md](./ENV_CONFIG.md)。

## 开发指南

### 添加新功能

1. 在 `drizzle/schema.ts` 定义数据模型
2. 运行 `pnpm db:push` 更新数据库
3. 在 `server/db.ts` 添加数据库操作函数
4. 在 `server/routers.ts` 添加tRPC路由
5. 在 `client/src/pages/` 创建前端页面
6. 在 `client/src/App.tsx` 注册路由

### 代码规范

- 使用 TypeScript 严格模式
- 遵循 ESLint 规则
- 组件使用函数式写法
- 使用 Tailwind CSS 进行样式开发

### 测试

```bash
# 运行所有测试
pnpm test

# 运行特定测试
pnpm test -- --grep "test name"
```

## 部署指南

### 生产环境部署

1. **构建前端**
   ```bash
   pnpm build
   ```

2. **配置Nginx**
   ```nginx
   server {
       listen 80;
       server_name your-domain.com;
       
       location / {
           proxy_pass http://localhost:3000;
       }
       
       location /api/python {
           proxy_pass http://localhost:8000;
       }
   }
   ```

3. **使用PM2管理进程**
   ```bash
   pm2 start ecosystem.config.js
   ```

### 安全建议

- 使用HTTPS
- 配置防火墙规则
- 定期更新依赖
- 启用日志监控
- 配置数据库备份

## 常见问题

### Q: 如何更换AI模型？

在管理后台的"模型配置"页面添加新的模型配置，支持OpenAI、DeepSeek、Moonshot等兼容API。

### Q: 知识图谱不显示？

确保Neo4j服务已启动，并检查连接配置是否正确。

### Q: 生成速度慢？

可以尝试：
1. 使用更快的模型（如gpt-4o-mini）
2. 减少生成字数
3. 检查网络连接

## 更新日志

### v1.0.0 (2025-12-12)

- 初始版本发布
- 完整的小说创作流程
- 知识图谱和AI评论系统
- 阅读模式和导出功能

## 许可证

MIT License

## 联系方式

- 项目主页: https://github.com/your-repo/ai_novel_generator
- 问题反馈: https://github.com/your-repo/ai_novel_generator/issues
- 邮箱: support@example.com

---

**幻写次元** - 让AI成为你的创作伙伴
