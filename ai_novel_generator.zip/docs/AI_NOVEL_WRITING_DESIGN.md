# AI小说写作系统深度设计方案

**版本**: 1.0  
**作者**: Manus AI  
**日期**: 2025年12月

---

## 目录

1. [核心挑战分析](#1-核心挑战分析)
2. [整体架构设计](#2-整体架构设计)
3. [上下文管理系统](#3-上下文管理系统)
4. [人物一致性系统](#4-人物一致性系统)
5. [历史信息追踪系统](#5-历史信息追踪系统)
6. [参考资料整合系统](#6-参考资料整合系统)
7. [Prompt工程设计](#7-prompt工程设计)
8. [实施建议](#8-实施建议)

---

## 1. 核心挑战分析

### 1.1 AI写小说面临的主要问题

| 问题类型 | 具体表现 | 影响程度 |
|----------|----------|----------|
| **上下文遗忘** | AI无法记住前文细节，导致情节断裂 | 严重 |
| **人物漂移** | 角色性格、说话方式前后不一致 | 严重 |
| **世界观混乱** | 设定前后矛盾，逻辑不通 | 中等 |
| **情节重复** | 类似情节反复出现，缺乏新意 | 中等 |
| **伏笔遗失** | 前文埋下的伏笔后文无法呼应 | 中等 |
| **时间线错乱** | 事件发生顺序混乱 | 轻微 |

### 1.2 问题根源

```mermaid
graph TB
    subgraph "LLM固有限制"
        A[上下文窗口有限] --> D[无法记住全部内容]
        B[无状态推理] --> E[每次生成独立]
        C[概率采样] --> F[输出不确定性]
    end
    
    subgraph "小说创作特点"
        G[长篇内容] --> J[远超上下文窗口]
        H[复杂人物关系] --> K[难以压缩表达]
        I[多线叙事] --> L[需要全局视角]
    end
    
    D --> M[内容不连贯]
    E --> M
    J --> M
    K --> N[人物不一致]
    L --> O[情节矛盾]
```

---

## 2. 整体架构设计

### 2.1 系统总体架构

```mermaid
graph TB
    subgraph "输入层"
        A[用户输入] --> B[创作意图解析]
        B --> C[任务分解]
    end
    
    subgraph "记忆系统"
        D[短期记忆<br/>当前章节上下文]
        E[工作记忆<br/>近期章节摘要]
        F[长期记忆<br/>向量检索]
        G[结构记忆<br/>知识图谱]
    end
    
    subgraph "检索增强层"
        H[相关性检索]
        I[人物信息检索]
        J[情节线索检索]
        K[世界观检索]
    end
    
    subgraph "生成层"
        L[上下文构建]
        M[Prompt组装]
        N[LLM生成]
        O[后处理校验]
    end
    
    subgraph "存储层"
        P[(MySQL<br/>结构数据)]
        Q[(Milvus<br/>向量存储)]
        R[(Neo4j<br/>知识图谱)]
    end
    
    C --> D
    C --> H
    D --> L
    E --> L
    H --> F
    H --> G
    F --> I
    F --> J
    G --> I
    G --> K
    I --> L
    J --> L
    K --> L
    L --> M
    M --> N
    N --> O
    O --> P
    O --> Q
    O --> R
```

### 2.2 多层记忆架构

模仿人类记忆系统，设计四层记忆架构：

```mermaid
graph LR
    subgraph "短期记忆 (4K tokens)"
        A[当前章节内容]
        B[最近对话]
        C[即时上下文]
    end
    
    subgraph "工作记忆 (8K tokens)"
        D[近5章摘要]
        E[当前情节线]
        F[活跃人物状态]
    end
    
    subgraph "长期记忆 (向量库)"
        G[全部章节向量]
        H[人物档案向量]
        I[情节事件向量]
        J[世界设定向量]
    end
    
    subgraph "结构记忆 (知识图谱)"
        K[人物关系图]
        L[事件因果链]
        M[时间线图谱]
        N[地点关联图]
    end
    
    A --> D
    D --> G
    G --> K
```

---

## 3. 上下文管理系统

### 3.1 上下文窗口分配策略

LLM的上下文窗口是有限资源，需要精心分配：

| 区域 | 占比 | 内容 | 优先级 |
|------|------|------|--------|
| 系统提示 | 10% | 角色设定、写作风格指令 | 最高 |
| 人物档案 | 15% | 当前场景涉及的人物信息 | 高 |
| 情节上下文 | 25% | 近期章节摘要、当前情节线 | 高 |
| RAG检索结果 | 20% | 相关历史内容、伏笔线索 | 中 |
| 当前章节 | 20% | 已生成的当前章节内容 | 中 |
| 生成空间 | 10% | 留给模型输出 | - |

### 3.2 滑动窗口机制

```mermaid
sequenceDiagram
    participant U as 用户
    participant S as 系统
    participant M as 记忆管理器
    participant L as LLM
    
    U->>S: 请求生成第N章
    S->>M: 获取上下文
    
    M->>M: 加载短期记忆<br/>(第N-1章完整内容)
    M->>M: 加载工作记忆<br/>(第N-5到N-2章摘要)
    M->>M: RAG检索长期记忆<br/>(相关历史片段)
    M->>M: 查询知识图谱<br/>(人物状态、关系)
    
    M->>S: 返回组装后的上下文
    S->>L: 发送Prompt
    L->>S: 流式生成内容
    
    S->>M: 更新记忆
    M->>M: 当前章节→短期记忆
    M->>M: 生成摘要→工作记忆
    M->>M: 向量化→长期记忆
    M->>M: 提取实体→知识图谱
```

### 3.3 智能摘要生成

每章生成后，自动提取关键信息：

```mermaid
flowchart TB
    A[完整章节内容] --> B[LLM摘要生成]
    
    B --> C[情节摘要<br/>200字以内]
    B --> D[人物动态<br/>状态变化]
    B --> E[新增设定<br/>世界观补充]
    B --> F[伏笔标记<br/>待回收线索]
    B --> G[情感基调<br/>氛围记录]
    
    C --> H[存入工作记忆]
    D --> I[更新人物档案]
    E --> J[更新世界设定]
    F --> K[加入伏笔追踪]
    G --> L[情感曲线记录]
```

---

## 4. 人物一致性系统

### 4.1 人物档案结构

```mermaid
graph TB
    subgraph "人物核心档案"
        A[基础信息]
        B[性格特征]
        C[说话风格]
        D[行为模式]
    end
    
    subgraph "动态状态"
        E[当前位置]
        F[情绪状态]
        G[目标动机]
        H[秘密/隐藏信息]
    end
    
    subgraph "关系网络"
        I[与其他人物关系]
        J[关系变化历史]
        K[互动记录]
    end
    
    subgraph "成长轨迹"
        L[能力变化]
        M[认知变化]
        N[关键转折点]
    end
    
    A --> E
    B --> F
    C --> K
    D --> G
```

### 4.2 人物一致性检查流程

```mermaid
flowchart TB
    A[生成内容] --> B{人物行为检查}
    
    B --> C[性格一致性]
    B --> D[说话风格]
    B --> E[能力范围]
    B --> F[关系合理性]
    
    C --> G{是否一致?}
    D --> G
    E --> G
    F --> G
    
    G -->|是| H[通过]
    G -->|否| I[标记问题]
    
    I --> J[提供修改建议]
    J --> K[重新生成/人工修改]
    K --> A
```

### 4.3 人物状态追踪表

| 追踪维度 | 更新时机 | 存储位置 | 用途 |
|----------|----------|----------|------|
| 物理位置 | 每次移动 | Neo4j | 场景合理性 |
| 情绪状态 | 每章结束 | MySQL | 行为动机 |
| 知识范围 | 获得新信息时 | Neo4j | 避免全知视角 |
| 能力等级 | 成长事件后 | MySQL | 战斗/技能描写 |
| 持有物品 | 获得/失去时 | MySQL | 道具使用 |
| 伤病状态 | 受伤/恢复时 | MySQL | 行动能力 |

---

## 5. 历史信息追踪系统

### 5.1 事件追踪架构

```mermaid
graph TB
    subgraph "事件类型"
        A[主线事件]
        B[支线事件]
        C[人物事件]
        D[世界事件]
    end
    
    subgraph "事件属性"
        E[时间戳]
        F[参与者]
        G[地点]
        H[因果关系]
        I[影响范围]
    end
    
    subgraph "事件状态"
        J[已发生]
        K[进行中]
        L[伏笔/待发生]
        M[已回收]
    end
    
    A --> E
    B --> E
    C --> F
    D --> G
    E --> J
    F --> K
    G --> L
    H --> M
```

### 5.2 伏笔管理系统

```mermaid
flowchart LR
    subgraph "伏笔埋设"
        A[创建伏笔] --> B[标记章节]
        B --> C[设定回收时机]
        C --> D[关联人物/事件]
    end
    
    subgraph "伏笔追踪"
        E[伏笔列表]
        F[到期提醒]
        G[关联检索]
    end
    
    subgraph "伏笔回收"
        H[自动提示] --> I[生成时注入]
        I --> J[标记已回收]
    end
    
    D --> E
    E --> F
    F --> H
    G --> I
```

### 5.3 时间线管理

```mermaid
gantt
    title 小说时间线示例
    dateFormat  YYYY-MM-DD
    section 主线
    主角入门           :a1, 2024-01-01, 30d
    初遇女主           :a2, after a1, 15d
    第一次冲突         :a3, after a2, 20d
    
    section 支线A
    发现身世秘密       :b1, 2024-02-01, 10d
    寻找线索           :b2, after b1, 25d
    
    section 支线B
    结识盟友           :c1, 2024-01-20, 15d
    共同冒险           :c2, after c1, 30d
```

---

## 6. 参考资料整合系统

### 6.1 参考资料类型

| 资料类型 | 用途 | 整合方式 |
|----------|------|----------|
| **世界观设定** | 确保设定一致 | 向量检索 + 知识图谱 |
| **类型小说范例** | 学习写作风格 | Few-shot示例 |
| **专业知识** | 增加真实感 | RAG检索 |
| **历史资料** | 历史背景准确 | 知识库查询 |
| **地理信息** | 场景描写准确 | 结构化数据 |

### 6.2 参考资料处理流程

```mermaid
flowchart TB
    subgraph "资料导入"
        A[上传文档] --> B[文档解析]
        B --> C[分块处理]
        C --> D[向量化]
        D --> E[存入Milvus]
    end
    
    subgraph "实体提取"
        B --> F[NER实体识别]
        F --> G[关系抽取]
        G --> H[存入Neo4j]
    end
    
    subgraph "检索使用"
        I[生成请求] --> J[语义检索]
        J --> K[相关片段]
        K --> L[注入Prompt]
    end
    
    E --> J
    H --> J
```

### 6.3 多源知识融合

```mermaid
graph TB
    subgraph "知识来源"
        A[用户设定]
        B[参考资料]
        C[生成内容]
        D[外部知识库]
    end
    
    subgraph "知识融合层"
        E[冲突检测]
        F[优先级排序]
        G[知识合并]
    end
    
    subgraph "统一知识库"
        H[世界观知识]
        I[人物知识]
        J[情节知识]
        K[背景知识]
    end
    
    A --> E
    B --> E
    C --> E
    D --> E
    E --> F
    F --> G
    G --> H
    G --> I
    G --> J
    G --> K
```

---

## 7. Prompt工程设计

### 7.1 Prompt结构模板

```mermaid
graph TB
    subgraph "Prompt结构"
        A[系统角色设定]
        B[写作风格指令]
        C[人物档案注入]
        D[情节上下文]
        E[RAG检索结果]
        F[当前任务指令]
        G[输出格式要求]
    end
    
    A --> B --> C --> D --> E --> F --> G
```

### 7.2 分层Prompt设计

| 层级 | 内容 | 示例 |
|------|------|------|
| **元层** | 定义AI角色 | "你是一位资深网络小说作家..." |
| **风格层** | 写作风格要求 | "文风细腻，善用环境描写烘托氛围..." |
| **约束层** | 硬性规则 | "人物必须符合档案设定，不得出现现代词汇..." |
| **上下文层** | 背景信息 | 人物档案、近期情节、世界设定 |
| **任务层** | 具体指令 | "请续写第15章，主角与反派首次正面交锋..." |
| **格式层** | 输出要求 | "字数3000-4000字，分段清晰..." |

### 7.3 动态Prompt组装

```mermaid
sequenceDiagram
    participant R as 请求处理器
    participant P as Prompt构建器
    participant M as 记忆系统
    participant K as 知识图谱
    participant V as 向量库
    
    R->>P: 生成请求(章节N)
    P->>P: 加载基础模板
    
    P->>M: 获取短期记忆
    M->>P: 返回近期内容
    
    P->>K: 查询相关人物
    K->>P: 返回人物档案
    
    P->>K: 查询人物关系
    K->>P: 返回关系图
    
    P->>V: 检索相关历史
    V->>P: 返回相似片段
    
    P->>P: 组装完整Prompt
    P->>R: 返回Prompt
```

---

## 8. 实施建议

### 8.1 优先级排序

```mermaid
graph LR
    subgraph "第一阶段 - 基础"
        A[人物档案系统]
        B[章节摘要生成]
        C[基础RAG检索]
    end
    
    subgraph "第二阶段 - 增强"
        D[知识图谱构建]
        E[伏笔追踪系统]
        F[多层记忆架构]
    end
    
    subgraph "第三阶段 - 优化"
        G[一致性自动检查]
        H[智能Prompt优化]
        I[多模型协作]
    end
    
    A --> D --> G
    B --> E --> H
    C --> F --> I
```

### 8.2 技术选型建议

| 组件 | 推荐方案 | 备选方案 |
|------|----------|----------|
| 向量数据库 | Milvus | Pinecone, Weaviate |
| 知识图谱 | Neo4j | ArangoDB, TigerGraph |
| LLM框架 | LangChain + LangGraph | LlamaIndex |
| Embedding模型 | text-embedding-3-large | BGE, M3E |
| 主生成模型 | GPT-4 / Claude-3 | DeepSeek, Qwen |

### 8.3 关键指标

| 指标 | 目标值 | 测量方法 |
|------|--------|----------|
| 人物一致性 | >95% | 人工抽检 |
| 情节连贯性 | >90% | 读者反馈 |
| 伏笔回收率 | >80% | 系统统计 |
| 生成速度 | <30s/章 | 系统监控 |
| 上下文利用率 | >85% | Token统计 |

---

## 总结

要让AI写出高质量的小说，核心在于构建一个**模拟人类记忆和创作过程**的系统：

1. **多层记忆架构**：短期、工作、长期、结构记忆协同工作
2. **人物一致性保障**：档案管理 + 状态追踪 + 一致性检查
3. **历史信息追踪**：事件图谱 + 伏笔管理 + 时间线控制
4. **参考资料整合**：向量检索 + 知识图谱 + 多源融合
5. **智能Prompt工程**：分层设计 + 动态组装 + 上下文优化

这套系统的目标是让AI不再是"无状态"的生成器，而是一个拥有"记忆"和"知识"的创作助手。

---

*文档结束*


---

## 附录A：详细数据流设计

### A.1 章节生成完整数据流

```mermaid
flowchart TB
    subgraph "1. 请求解析"
        A[用户请求生成第N章] --> B[解析章节需求]
        B --> C[提取关键词/主题]
    end
    
    subgraph "2. 上下文收集"
        C --> D[加载第N-1章完整内容]
        D --> E[加载第N-5到N-2章摘要]
        E --> F[加载当前章节细纲]
    end
    
    subgraph "3. 知识检索"
        F --> G[基于细纲关键词<br/>向量检索Milvus]
        G --> H[获取相关历史片段<br/>Top-K=5]
        
        F --> I[查询Neo4j<br/>涉及人物档案]
        I --> J[获取人物当前状态]
        
        F --> K[查询Neo4j<br/>待回收伏笔]
        K --> L[获取到期伏笔列表]
    end
    
    subgraph "4. Prompt组装"
        H --> M[构建RAG上下文块]
        J --> N[构建人物信息块]
        L --> O[构建伏笔提醒块]
        
        M --> P[Prompt模板填充]
        N --> P
        O --> P
        E --> P
        F --> P
    end
    
    subgraph "5. 内容生成"
        P --> Q[发送到LLM]
        Q --> R[流式接收响应]
        R --> S[实时显示给用户]
    end
    
    subgraph "6. 后处理"
        S --> T[一致性检查]
        T --> U{检查通过?}
        U -->|是| V[保存章节]
        U -->|否| W[标记问题<br/>建议修改]
    end
    
    subgraph "7. 记忆更新"
        V --> X[生成章节摘要]
        X --> Y[更新工作记忆]
        
        V --> Z[向量化章节内容]
        Z --> AA[存入Milvus]
        
        V --> AB[提取实体和事件]
        AB --> AC[更新Neo4j图谱]
        
        V --> AD[检查伏笔状态]
        AD --> AE[标记已回收伏笔]
    end
```

### A.2 人物状态更新流程

```mermaid
flowchart LR
    subgraph "事件触发"
        A[章节生成完成]
        B[用户手动编辑]
        C[批量导入]
    end
    
    subgraph "实体提取"
        D[NER识别人物]
        E[动作/状态识别]
        F[关系变化识别]
    end
    
    subgraph "状态计算"
        G[位置变更检测]
        H[情绪变化分析]
        I[能力变化检测]
        J[关系强度更新]
    end
    
    subgraph "图谱更新"
        K[更新人物节点属性]
        L[更新/创建关系边]
        M[添加事件节点]
        N[更新时间线]
    end
    
    A --> D
    B --> D
    C --> D
    D --> E --> F
    E --> G --> K
    E --> H --> K
    E --> I --> K
    F --> J --> L
    D --> M --> N
```

### A.3 RAG检索策略

```mermaid
flowchart TB
    subgraph "查询构建"
        A[原始查询] --> B[查询扩展]
        B --> C[关键词提取]
        B --> D[语义向量化]
    end
    
    subgraph "多路召回"
        C --> E[关键词匹配<br/>BM25]
        D --> F[向量相似度<br/>Cosine]
        D --> G[混合检索<br/>Hybrid]
    end
    
    subgraph "结果融合"
        E --> H[候选集合并]
        F --> H
        G --> H
        H --> I[重排序<br/>Cross-Encoder]
    end
    
    subgraph "过滤策略"
        I --> J[用户ID过滤]
        J --> K[小说ID过滤]
        K --> L[时间范围过滤]
        L --> M[去重处理]
    end
    
    subgraph "输出"
        M --> N[Top-K结果]
        N --> O[格式化为上下文]
    end
```

---

## 附录B：知识图谱Schema设计

### B.1 节点类型定义

```mermaid
classDiagram
    class Character {
        +int characterId
        +int novelId
        +int userId
        +string name
        +string role
        +string personality
        +string appearance
        +string background
        +string abilities
        +string currentLocation
        +string emotionalState
        +datetime createdAt
        +datetime updatedAt
    }
    
    class Location {
        +int locationId
        +int novelId
        +string name
        +string type
        +string description
        +string parentLocation
    }
    
    class Event {
        +int eventId
        +int novelId
        +string name
        +string description
        +int timePoint
        +int chapterNumber
        +string eventType
        +string status
    }
    
    class Item {
        +int itemId
        +int novelId
        +string name
        +string type
        +string description
        +string abilities
    }
    
    class Organization {
        +int orgId
        +int novelId
        +string name
        +string type
        +string description
        +string hierarchy
    }
    
    class Foreshadowing {
        +int foreshadowingId
        +int novelId
        +string content
        +int plantedChapter
        +int targetChapter
        +string status
        +string relatedCharacters
    }
```

### B.2 关系类型定义

```mermaid
graph LR
    subgraph "人物关系"
        A[KNOWS] --- B[认识]
        C[LOVES] --- D[爱慕]
        E[HATES] --- F[仇恨]
        G[FAMILY_OF] --- H[家人]
        I[FRIEND_OF] --- J[朋友]
        K[ENEMY_OF] --- L[敌人]
        M[MASTER_OF] --- N[师徒]
        O[SUBORDINATE_OF] --- P[上下级]
    end
    
    subgraph "人物-实体关系"
        Q[BELONGS_TO] --- R[属于组织]
        S[OWNS] --- T[拥有物品]
        U[LOCATED_AT] --- V[位于地点]
        W[PARTICIPATES_IN] --- X[参与事件]
    end
    
    subgraph "事件关系"
        Y[FOLLOWS] --- Z[时间顺序]
        AA[CAUSES] --- AB[因果关系]
        AC[HAPPENS_AT] --- AD[发生地点]
    end
```

---

## 附录C：Prompt模板示例

### C.1 章节生成Prompt结构

```
[系统角色]
你是一位资深的{genre}小说作家，擅长{style}风格的创作。
你的任务是根据提供的大纲和上下文，续写小说章节。

[写作规范]
1. 保持人物性格一致，对话符合人物设定
2. 情节发展自然流畅，与前文呼应
3. 适当使用环境描写和心理描写
4. 控制节奏，张弛有度
5. 注意伏笔的埋设和回收

[人物档案]
{character_profiles}

[近期情节摘要]
{recent_summaries}

[相关历史内容]
{rag_context}

[待回收伏笔]
{pending_foreshadowing}

[当前章节大纲]
{chapter_outline}

[任务]
请根据以上信息，续写第{chapter_number}章。
要求：
- 字数：{word_count}字左右
- 重点场景：{key_scenes}
- 情感基调：{emotional_tone}

[输出格式]
直接输出章节正文，无需标题。
```

### C.2 摘要生成Prompt

```
[任务]
请为以下章节内容生成结构化摘要。

[章节内容]
{chapter_content}

[输出格式]
请按以下JSON格式输出：
{
  "plot_summary": "情节摘要（200字以内）",
  "character_updates": [
    {"name": "人物名", "changes": "状态变化描述"}
  ],
  "new_settings": ["新增的世界观设定"],
  "foreshadowing": [
    {"content": "伏笔内容", "type": "planted/recalled"}
  ],
  "emotional_tone": "本章情感基调",
  "key_events": ["关键事件列表"]
}
```

---

## 附录D：参考文献

[1] LangChain Documentation - Memory. https://python.langchain.com/docs/modules/memory/

[2] Milvus Documentation - Vector Search. https://milvus.io/docs/search.md

[3] Neo4j Graph Database Documentation. https://neo4j.com/docs/

[4] OpenAI - Best Practices for Prompt Engineering. https://platform.openai.com/docs/guides/prompt-engineering

[5] RAG (Retrieval-Augmented Generation) - Lewis et al., 2020. https://arxiv.org/abs/2005.11401

[6] LangGraph Documentation - Multi-Agent Workflows. https://langchain-ai.github.io/langgraph/

[7] Anthropic - Long Context Window Best Practices. https://docs.anthropic.com/claude/docs/long-context-window-tips

---

*附录结束*
