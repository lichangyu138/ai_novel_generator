# 环境变量配置说明

## 概述

本文档详细说明AI小说生成系统所需的环境变量配置。

## 数据库配置

### MySQL配置

```bash
MYSQL_HOST=localhost
MYSQL_PORT=3306
MYSQL_USER=novel_user
MYSQL_PASSWORD=novel_password
MYSQL_DATABASE=ai_novel_generator
MYSQL_ROOT_PASSWORD=root123456

# 完整的数据库连接URL
DATABASE_URL=mysql://novel_user:novel_password@localhost:3306/ai_novel_generator
```

### Redis配置

```bash
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=
REDIS_URL=redis://localhost:6379
```

### Neo4j配置

```bash
NEO4J_URI=bolt://localhost:7687
NEO4J_USER=neo4j
NEO4J_PASSWORD=neo4j123456
```

### Milvus配置

```bash
MILVUS_HOST=localhost
MILVUS_PORT=19530
```

### Elasticsearch配置（可选）

```bash
ELASTICSEARCH_HOST=localhost
ELASTICSEARCH_PORT=9200
```

## 认证配置

### JWT密钥

```bash
# 生产环境请使用强密钥
JWT_SECRET=your-super-secret-jwt-key-change-in-production
```

### OAuth配置

```bash
VITE_APP_ID=your-app-id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://login.manus.im
```

## AI模型配置

### OpenAI配置

```bash
OPENAI_API_KEY=sk-your-openai-api-key
OPENAI_API_BASE=https://api.openai.com/v1
```

### 兼容API配置

```bash
# DeepSeek
OPENAI_API_BASE=https://api.deepseek.com/v1

# Moonshot
OPENAI_API_BASE=https://api.moonshot.cn/v1

# 智谱AI
OPENAI_API_BASE=https://open.bigmodel.cn/api/paas/v4
```

### 默认模型

```bash
DEFAULT_MODEL=gpt-4o-mini
DEFAULT_EMBEDDING_MODEL=text-embedding-3-small
```

## 应用配置

```bash
NODE_ENV=development
PORT=3000
PYTHON_PORT=8000
VITE_APP_TITLE=幻写次元
```

## 存储配置

### S3存储

```bash
S3_BUCKET=your-bucket
S3_REGION=us-east-1
S3_ACCESS_KEY=your-access-key
S3_SECRET_KEY=your-secret-key
```

### 本地上传

```bash
UPLOAD_DIR=./uploads
```

## 其他配置

```bash
LOG_LEVEL=info
CORS_ORIGIN=http://localhost:3000
RATE_LIMIT_MAX=100
RATE_LIMIT_WINDOW=60000
```

## 配置优先级

1. 环境变量
2. .env 文件
3. 默认值

## 安全建议

1. **不要提交敏感信息**：确保 `.env` 文件在 `.gitignore` 中
2. **使用强密钥**：JWT_SECRET 和数据库密码应使用强随机字符串
3. **定期轮换**：定期更换 API 密钥和密码
4. **最小权限**：数据库用户只授予必要的权限
