# 技术架构文档

## 系统架构概览

AI小说生成系统采用前后端分离的微服务架构，结合多种数据库和AI服务，提供完整的小说创作解决方案。

```
┌─────────────────────────────────────────────────────────────────┐
│                         客户端层                                 │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │              React 19 + TypeScript + Tailwind            │   │
│  │         (Vite构建 / tRPC客户端 / D3.js可视化)            │   │
│  └─────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                         网关层                                   │
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                    Nginx 反向代理                         │   │
│  │              (负载均衡 / SSL终止 / 静态资源)              │   │
│  └─────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────┘
                              │
              ┌───────────────┴───────────────┐
              ▼                               ▼
┌─────────────────────────┐     ┌─────────────────────────┐
│     Node.js 后端        │     │     Python 后端         │
│  ┌───────────────────┐  │     │  ┌───────────────────┐  │
│  │ Express + tRPC    │  │     │  │ FastAPI + Uvicorn │  │
│  │ Drizzle ORM       │  │     │  │ LangChain/LangGraph│  │
│  │ JWT认证           │  │     │  │ 流式生成          │  │
│  └───────────────────┘  │     │  └───────────────────┘  │
└─────────────────────────┘     └─────────────────────────┘
              │                               │
              └───────────────┬───────────────┘
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                         数据层                                   │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐           │
│  │  MySQL   │ │  Redis   │ │  Neo4j   │ │  Milvus  │           │
│  │ 主数据库  │ │ 缓存/会话 │ │ 知识图谱  │ │ 向量检索  │           │
│  └──────────┘ └──────────┘ └──────────┘ └──────────┘           │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                         AI服务层                                 │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  OpenAI / DeepSeek / Moonshot / 本地模型                  │  │
│  │  (文本生成 / 嵌入向量 / 重排序)                            │  │
│  └──────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

## 技术栈详解

### 前端技术栈

| 技术 | 版本 | 用途 |
|------|------|------|
| React | 19.x | UI框架 |
| TypeScript | 5.x | 类型安全 |
| Vite | 7.x | 构建工具 |
| Tailwind CSS | 4.x | 样式框架 |
| tRPC | 11.x | 类型安全的API调用 |
| D3.js | 7.x | 数据可视化 |
| Wouter | 3.x | 路由管理 |
| Radix UI | - | 无障碍组件库 |

### Node.js后端技术栈

| 技术 | 版本 | 用途 |
|------|------|------|
| Express | 4.x | Web框架 |
| tRPC | 11.x | API层 |
| Drizzle ORM | - | 数据库ORM |
| Superjson | - | 序列化 |
| JWT | - | 认证 |

### Python后端技术栈

| 技术 | 版本 | 用途 |
|------|------|------|
| FastAPI | 0.100+ | Web框架 |
| Uvicorn | - | ASGI服务器 |
| LangChain | 0.1+ | LLM编排 |
| LangGraph | - | 工作流编排 |
| SQLAlchemy | 2.x | ORM |
| Pydantic | 2.x | 数据验证 |

### 数据库

| 数据库 | 用途 | 数据类型 |
|--------|------|----------|
| MySQL 8.0 | 主数据库 | 结构化数据（用户、小说、章节等） |
| Redis 7.0 | 缓存层 | 会话、Token、热点数据缓存 |
| Neo4j 5.x | 图数据库 | 知识图谱（人物关系、事件网络） |
| Milvus 2.3 | 向量数据库 | 文本嵌入向量、相似度检索 |

## 核心模块设计

### 1. 认证模块

```
┌─────────────────────────────────────────────────────────────┐
│                      认证流程                                │
│                                                             │
│  用户 ──► OAuth登录 ──► 回调处理 ──► JWT生成 ──► Redis存储   │
│                                                             │
│  请求 ──► JWT验证 ──► Redis校验 ──► 用户上下文 ──► 业务处理  │
└─────────────────────────────────────────────────────────────┘
```

**Token管理策略**：
- Access Token有效期：24小时
- Refresh Token有效期：7天
- Redis存储Token白名单，支持主动失效
- 支持多设备登录管理

### 2. 章节生成模块

```
┌─────────────────────────────────────────────────────────────┐
│                    章节生成流程                              │
│                                                             │
│  1. 查询知识库                                              │
│     ├── 获取人物信息                                        │
│     ├── 获取前文摘要                                        │
│     ├── 获取相关事件                                        │
│     └── 向量检索相似内容                                    │
│                                                             │
│  2. 构建Prompt                                              │
│     ├── 系统提示（作家风格）                                │
│     ├── 上下文信息                                          │
│     ├── 细纲内容                                            │
│     └── 生成指令                                            │
│                                                             │
│  3. 流式生成                                                │
│     ├── 调用LLM API                                         │
│     ├── SSE推送到前端                                       │
│     └── 实时显示内容                                        │
│                                                             │
│  4. 后处理                                                  │
│     ├── 去AI味优化                                          │
│     ├── 提取知识信息                                        │
│     ├── 更新知识库                                          │
│     └── 生成AI评论                                          │
└─────────────────────────────────────────────────────────────┘
```

### 3. 知识图谱模块

```
┌─────────────────────────────────────────────────────────────┐
│                    知识图谱结构                              │
│                                                             │
│  节点类型:                                                  │
│  ├── Novel (小说)                                           │
│  ├── Character (角色)                                       │
│  ├── Event (事件)                                           │
│  ├── Location (地点)                                        │
│  ├── Item (物品)                                            │
│  └── Organization (组织)                                    │
│                                                             │
│  关系类型:                                                  │
│  ├── 角色关系: PARENT_OF, SPOUSE_OF, FRIEND_OF, ENEMY_OF   │
│  ├── 组织关系: MEMBER_OF, LEADER_OF                        │
│  ├── 事件关系: PARTICIPATES_IN, CAUSES, FOLLOWS            │
│  └── 空间关系: LIVES_IN, OCCURS_AT                         │
└─────────────────────────────────────────────────────────────┘
```

### 4. RAG检索模块

```
┌─────────────────────────────────────────────────────────────┐
│                    RAG检索流程                               │
│                                                             │
│  查询 ──► 嵌入向量 ──► Milvus检索 ──► Rerank重排 ──► 结果   │
│                                                             │
│  嵌入模型: text-embedding-3-small / bge-large-zh           │
│  重排模型: bge-reranker-large / cohere-rerank              │
│  检索策略: 混合检索（向量 + 关键词）                         │
└─────────────────────────────────────────────────────────────┘
```

## 数据模型

### 核心实体关系

```
┌──────────┐     ┌──────────┐     ┌──────────┐
│   User   │────<│  Novel   │────<│ Chapter  │
└──────────┘     └──────────┘     └──────────┘
                      │                │
                      │                │
                 ┌────┴────┐     ┌────┴────┐
                 │         │     │         │
            ┌────▼───┐ ┌───▼────┐ ┌───▼────┐
            │Character│ │Outline │ │ChapterOutline│
            └────┬───┘ └────────┘ └────────┘
                 │
            ┌────▼────────┐
            │Relationship │
            └─────────────┘
```

### 主要数据表

| 表名 | 描述 | 主要字段 |
|------|------|----------|
| users | 用户信息 | id, name, email, role |
| novels | 小说信息 | id, title, genre, style, writer_style |
| characters | 角色信息 | id, name, gender, description |
| character_relationships | 角色关系 | character_id, related_id, type |
| outlines | 大纲 | id, novel_id, title, content |
| detailed_outlines | 细纲 | id, novel_id, chapter_range, content |
| chapters | 章节 | id, novel_id, chapter_number, content |
| chapter_outlines | 章节细纲 | id, chapter_id, previous_summary |
| chapter_reviews | AI评论 | id, chapter_id, quality_score |
| foreshadowing | 伏笔 | id, novel_id, content, status |
| knowledge_entries | 知识库条目 | id, novel_id, category, content |
| events | 事件 | id, novel_id, title, timeline_order |
| version_history | 版本历史 | id, entity_type, entity_id, content |

## API设计

### tRPC路由结构

```typescript
// 路由树结构
appRouter = {
  auth: {
    me: publicProcedure,
    logout: protectedProcedure
  },
  novels: {
    list: protectedProcedure,
    get: protectedProcedure,
    create: protectedProcedure,
    update: protectedProcedure,
    delete: protectedProcedure
  },
  characters: {
    list: protectedProcedure,
    create: protectedProcedure,
    update: protectedProcedure,
    delete: protectedProcedure
  },
  chapters: {
    list: protectedProcedure,
    create: protectedProcedure,
    update: protectedProcedure,
    delete: protectedProcedure
  },
  ai: {
    generateOutline: protectedProcedure,
    generateChapter: protectedProcedure,
    generateCharacterDescription: protectedProcedure,
    modifyContent: protectedProcedure
  },
  // ... 更多路由
}
```

### Python API端点

```python
# 流式生成
POST /api/generate/chapter/stream
Request: {
  novel_id: int,
  chapter_number: int,
  word_count: int,
  outline: str
}
Response: SSE stream

# 知识库查询
POST /api/knowledge/query
Request: {
  novel_id: int,
  query: str,
  top_k: int
}
Response: {
  results: [...]
}

# 知识库同步
POST /api/knowledge/sync
Request: {
  novel_id: int,
  chapter_id: int,
  content: str
}
Response: {
  extracted: {...}
}
```

## 性能优化

### 缓存策略

| 缓存层 | 数据类型 | TTL | 策略 |
|--------|----------|-----|------|
| Redis L1 | 热点数据 | 5分钟 | LRU |
| Redis L2 | 会话数据 | 24小时 | 主动失效 |
| 本地缓存 | 配置数据 | 1小时 | 定时刷新 |

### 数据库优化

- **索引优化**：为常用查询字段建立索引
- **分页查询**：大数据量使用游标分页
- **连接池**：复用数据库连接
- **读写分离**：主从复制（生产环境）

### 生成优化

- **流式输出**：减少首字节时间
- **并行处理**：知识库查询并行化
- **缓存预热**：预加载常用数据

## 安全设计

### 认证安全

- JWT签名使用RS256算法
- Token存储在HttpOnly Cookie
- CSRF保护
- 速率限制

### 数据安全

- 敏感数据加密存储
- SQL注入防护（参数化查询）
- XSS防护（输出编码）
- 输入验证（Zod/Pydantic）

### 网络安全

- HTTPS强制
- CORS配置
- 请求大小限制
- 日志脱敏

## 部署架构

### 单机部署

```
┌─────────────────────────────────────────┐
│              单机服务器                  │
│  ┌─────────────────────────────────┐   │
│  │  Docker Compose                  │   │
│  │  ├── nginx                       │   │
│  │  ├── node-backend                │   │
│  │  ├── python-backend              │   │
│  │  ├── mysql                       │   │
│  │  ├── redis                       │   │
│  │  ├── neo4j                       │   │
│  │  └── milvus                      │   │
│  └─────────────────────────────────┘   │
└─────────────────────────────────────────┘
```

### 分布式部署

```
┌─────────────────────────────────────────────────────────────┐
│                        负载均衡器                            │
└─────────────────────────────────────────────────────────────┘
                              │
        ┌─────────────────────┼─────────────────────┐
        ▼                     ▼                     ▼
┌───────────────┐     ┌───────────────┐     ┌───────────────┐
│   应用节点1    │     │   应用节点2    │     │   应用节点3    │
│  Node + Python │     │  Node + Python │     │  Node + Python │
└───────────────┘     └───────────────┘     └───────────────┘
        │                     │                     │
        └─────────────────────┼─────────────────────┘
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                        数据层集群                            │
│  MySQL主从  │  Redis集群  │  Neo4j集群  │  Milvus集群        │
└─────────────────────────────────────────────────────────────┘
```

## 监控与运维

### 监控指标

- **应用指标**：QPS、响应时间、错误率
- **系统指标**：CPU、内存、磁盘、网络
- **业务指标**：生成次数、用户活跃度

### 日志管理

- 结构化日志（JSON格式）
- 日志分级（DEBUG/INFO/WARN/ERROR）
- 集中式日志收集（ELK/Loki）

### 告警规则

| 指标 | 阈值 | 级别 |
|------|------|------|
| 错误率 | > 1% | 警告 |
| 响应时间P99 | > 3s | 警告 |
| CPU使用率 | > 80% | 警告 |
| 内存使用率 | > 85% | 警告 |
| 磁盘使用率 | > 90% | 严重 |

## 扩展性设计

### 水平扩展

- 无状态应用设计
- 会话外部化（Redis）
- 数据库读写分离
- 缓存分布式

### 功能扩展

- 插件化架构
- 模型适配器模式
- 事件驱动设计
- API版本管理

---

**文档版本**: 1.0.0  
**最后更新**: 2025-12-12  
**作者**: Manus AI
