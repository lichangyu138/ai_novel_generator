# 幻写次元 - AI小说生成系统技术文档

**版本**: 1.0.0  
**作者**: Manus AI  
**更新日期**: 2025年12月

---

## 目录

1. [系统概述](#1-系统概述)
2. [系统架构](#2-系统架构)
3. [技术栈](#3-技术栈)
4. [功能模块](#4-功能模块)
5. [数据流程](#5-数据流程)
6. [部署指南](#6-部署指南)
7. [API文档](#7-api文档)
8. [配置说明](#8-配置说明)

---

## 1. 系统概述

### 1.1 系统简介

幻写次元是一个AI辅助小说创作平台，旨在帮助作者从设定到完整章节生成的全流程创作。系统集成了大语言模型（LLM）、向量检索（RAG）和知识图谱技术，确保生成内容的连贯性和人物一致性。

### 1.2 核心价值

| 特性 | 描述 |
|------|------|
| **全流程创作** | 从世界观设定、大纲、细纲到章节内容的完整创作链路 |
| **知识图谱** | 使用Neo4j存储人物关系、世界观、时间线，确保人物不偏离预设 |
| **向量检索** | 使用Milvus存储小说关键信息，通过RAG技术保证情节连贯 |
| **流式生成** | 实时显示AI生成进度，提升用户体验 |
| **多模型支持** | 支持OpenAI、Anthropic、DeepSeek等多种AI模型，支持自定义API |
| **全文搜索** | 使用Elasticsearch实现中文分词、拼音搜索、高亮显示等高级搜索功能 |

### 1.3 目标用户

- 网络小说作者
- 内容创作者
- 剧本编剧
- 游戏剧情策划

---

## 2. 系统架构

### 2.1 整体架构图

```mermaid
graph TB
    subgraph "前端层"
        A[React前端] --> B[用户界面]
        B --> C[小说管理]
        B --> D[内容生成]
        B --> E[知识图谱可视化]
    end
    
    subgraph "API网关层"
        F[Node.js tRPC API]
        G[Python FastAPI]
    end
    
    subgraph "服务层"
        H[认证服务]
        I[小说管理服务]
        J[AI生成服务]
        K[知识库服务]
        L[图谱服务]
    end
    
    subgraph "AI层"
        M[LangChain]
        N[LangGraph]
        O[Embedding模型]
    end
    
subgraph "数据层"
        P[(​MySQL)]
        Q[(​Milvus)]
        R[(​Neo4j)]
        S[(​Elasticsearch)]
    end
    
    A --> F
    A --> G
    F --> H
    F --> I
    G --> J
    G --> K
    G --> L
    J --> M
    J --> N
    K --> O
    H --> P
    I --> P
    K --> Q
    L --> R
```

### 2.2 部署架构图

```mermaid
graph LR
    subgraph "客户端"
        A[浏览器]
    end
    
    subgraph "应用服务器"
        B[Nginx反向代理]
        C[React静态资源]
        D[Node.js后端:3000]
        E[Python后端:8000]
    end
    
    subgraph "数据服务器"
        F[(MySQL:3306)]
        G[(Milvus:19530)]
        H[(Neo4j:7687)]
        K[(Elasticsearch:9200)]
    end
    
    subgraph "外部服务"
        I[OpenAI API]
        J[其他LLM API]
    end
    
    A --> B
    B --> C
    B --> D
    B --> E
    D --> F
    E --> F
    E --> G
    E --> H
    E --> I
    E --> J
```

### 2.3 数据隔离架构

系统采用多租户架构，每个用户的数据完全隔离：

```mermaid
graph TB
    subgraph "用户A的数据空间"
        A1[小说项目A1]
        A2[小说项目A2]
        A3[向量分区A]
        A4[图谱命名空间A]
    end
    
    subgraph "用户B的数据空间"
        B1[小说项目B1]
        B2[小说项目B2]
        B3[向量分区B]
        B4[图谱命名空间B]
    end
    
    subgraph "数据存储"
        C[(MySQL<br/>user_id过滤)]
        D[(Milvus<br/>partition隔离)]
        E[(Neo4j<br/>userId属性)]
    end
    
    A1 --> C
    A2 --> C
    A3 --> D
    A4 --> E
    B1 --> C
    B2 --> C
    B3 --> D
    B4 --> E
```

---

## 3. 技术栈

### 3.1 前端技术

| 技术 | 版本 | 用途 |
|------|------|------|
| React | 19.x | 前端框架 |
| TypeScript | 5.x | 类型安全 |
| TailwindCSS | 4.x | 样式框架 |
| tRPC | 11.x | 类型安全的API调用 |
| Wouter | 3.x | 路由管理 |
| Tanstack Query | 5.x | 数据获取和缓存 |

### 3.2 后端技术

| 技术 | 版本 | 用途 |
|------|------|------|
| Node.js | 22.x | JavaScript运行时 |
| Express | 4.x | Web框架 |
| Python | 3.11+ | Python运行时 |
| FastAPI | 0.100+ | Python Web框架 |
| LangChain | 0.3+ | LLM应用框架 |
| LangGraph | 0.2+ | 多Agent工作流 |

### 3.3 数据存储

| 技术 | 版本 | 用途 |
|------|------|------|
| MySQL | 8.0+ | 结构化数据存储 |
| Milvus | 2.3+ | 向量数据库（语义检索） |
| Neo4j | 5.x | 图数据库（关系查询） |
| Elasticsearch | 8.x | 全文搜索引擎（关键词搜索） |

### 3.4 搜索引擎分工

| 引擎 | 使用场景 | 优势 |
|------|----------|------|
| **Milvus** | 语义相似度检索（RAG场景） | 找“意思相近”的内容 |
| **Elasticsearch** | 关键词精确/模糊搜索 | 找“包含某词”的内容，支持中文分词、拼音搜索 |
| **Neo4j** | 关系查询 | 找“与某人物相关”的内容 |

---

## 4. 功能模块

### 4.1 用户系统

```mermaid
flowchart LR
    A[用户] --> B{已登录?}
    B -->|否| C[登录/注册]
    B -->|是| D[进入系统]
    C --> E[用户名密码认证]
    E --> F[JWT Token生成]
    F --> D
    D --> G[普通用户功能]
    D --> H{是管理员?}
    H -->|是| I[管理员功能]
```

**功能说明**：
- 独立的用户名/密码认证系统
- JWT Token认证机制
- 用户角色：普通用户(user)、管理员(admin)
- 数据隔离：用户只能访问自己的数据

### 4.2 小说项目管理

```mermaid
flowchart TB
    A[创建小说] --> B[填写基本信息]
    B --> C[标题/类型/风格]
    B --> D[简介/提示词]
    B --> E[世界观设定]
    C --> F[保存项目]
    D --> F
    E --> F
    F --> G[项目列表]
    G --> H[进入项目]
    H --> I[大纲管理]
    H --> J[人物设定]
    H --> K[章节管理]
    H --> L[知识图谱]
```

### 4.3 内容生成流程

```mermaid
flowchart TB
    subgraph "大纲生成"
        A[输入设定和提示词] --> B[AI生成大纲]
        B --> C[流式输出]
        C --> D[用户审核/修改]
        D --> E[保存大纲]
    end
    
    subgraph "细纲生成"
        E --> F[按5章分组]
        F --> G[AI生成细纲]
        G --> H[流式输出]
        H --> I[用户审核/修改]
        I --> J[保存细纲]
    end
    
    subgraph "章节生成"
        J --> K[选择章节]
        K --> L[RAG检索相关内容]
        L --> M[知识图谱查询]
        M --> N[AI生成章节]
        N --> O[流式输出]
        O --> P[用户审核]
        P -->|通过| Q[保存章节]
        P -->|修改意见| R[AI重新生成]
        R --> O
    end
```

### 4.4 知识图谱系统

```mermaid
graph TB
    subgraph "节点类型"
        A((人物))
        B((地点))
        C((事件))
        D((物品))
        E((组织))
    end
    
    subgraph "关系类型"
        A -->|认识| A
        A -->|爱慕| A
        A -->|仇恨| A
        A -->|家人| A
        A -->|属于| E
        A -->|拥有| D
        A -->|位于| B
        A -->|参与| C
        C -->|发生于| B
        C -->|导致| C
    end
```

### 4.5 RAG检索流程

```mermaid
sequenceDiagram
    participant U as 用户
    participant S as 系统
    participant E as Embedding模型
    participant M as Milvus
    participant L as LLM
    
    U->>S: 请求生成章节
    S->>E: 章节大纲文本
    E->>S: 向量嵌入
    S->>M: 相似度检索
    M->>S: 相关知识片段
    S->>S: 构建上下文
    S->>L: 上下文+提示词
    L->>S: 流式生成内容
    S->>U: 实时显示
```

---

## 5. 数据流程

### 5.1 数据模型关系

```mermaid
erDiagram
    USERS ||--o{ NOVELS : owns
    USERS ||--o{ MODEL_CONFIGS : configures
    NOVELS ||--o{ CHARACTERS : contains
    NOVELS ||--o{ OUTLINES : has
    NOVELS ||--o{ CHAPTERS : contains
    NOVELS ||--o{ KNOWLEDGE_ENTRIES : stores
    OUTLINES ||--o{ DETAILED_OUTLINES : generates
    NOVELS ||--o{ GENERATION_HISTORY : records
    
    USERS {
        int id PK
        string username
        string password_hash
        string role
    }
    
    NOVELS {
        int id PK
        int user_id FK
        string title
        string genre
        string style
    }
    
    CHARACTERS {
        int id PK
        int novel_id FK
        string name
        string role
        text personality
    }
    
    CHAPTERS {
        int id PK
        int novel_id FK
        int chapter_number
        text content
        string status
    }
```

### 5.2 生成历史追踪

系统记录所有生成操作的历史，支持版本回溯：

| 字段 | 说明 |
|------|------|
| type | 生成类型：outline/detailed_outline/chapter/revision |
| prompt | 使用的提示词 |
| result | 生成结果 |
| model_used | 使用的模型 |
| tokens_used | 消耗的token数 |

---

## 6. 部署指南

### 6.1 环境要求

| 组件 | 最低要求 | 推荐配置 |
|------|----------|----------|
| CPU | 2核 | 4核+ |
| 内存 | 4GB | 8GB+ |
| 存储 | 20GB | 50GB+ |
| Python | 3.11+ | 3.11 |
| Node.js | 18+ | 22 |

### 6.2 快速启动流程

```mermaid
flowchart TB
    A[克隆项目] --> B[安装依赖]
    B --> C[配置环境变量]
    C --> D[初始化数据库]
    D --> E[启动服务]
    
    subgraph "安装依赖"
        B1[pnpm install]
        B2[pip install -r requirements.txt]
    end
    
    subgraph "初始化数据库"
        D1[MySQL: init_mysql.sql]
        D2[Neo4j: init_neo4j.cypher]
        D3[Milvus: init_milvus.py]
    end
    
    subgraph "启动服务"
        E1[Node.js前端: pnpm dev]
        E2[Python后端: python main.py]
    end
    
    B --> B1
    B --> B2
    D --> D1
    D --> D2
    D --> D3
    E --> E1
    E --> E2
```

### 6.3 详细部署步骤

**步骤1：克隆项目**
```bash
git clone <repository-url>
cd ai_novel_generator
```

**步骤2：安装Node.js依赖**
```bash
pnpm install
```

**步骤3：安装Python依赖**
```bash
cd python_backend
pip install -r requirements.txt
```

**步骤4：配置环境变量**
```bash
# Node.js环境
cp .env.example .env

# Python环境
cd python_backend
cp env.template .env
```

**步骤5：初始化数据库**
```bash
# MySQL
mysql -u root -p < scripts/init_mysql.sql

# Neo4j (通过Neo4j Browser执行)
# 导入 scripts/init_neo4j.cypher

# Milvus
python scripts/init_milvus.py
```

**步骤6：启动服务**
```bash
# 启动Node.js前端和API
pnpm dev

# 启动Python后端（新终端）
cd python_backend
python main.py
```

### 6.4 服务端口

| 服务 | 端口 | 说明 |
|------|------|------|
| React前端 | 3000 | 开发服务器 |
| Python API | 8000 | FastAPI后端 |
| MySQL | 3306 | 数据库 |
| Milvus | 19530 | 向量数据库 |
| Neo4j | 7687 | 图数据库 |
| Neo4j Browser | 7474 | 图数据库Web界面 |

---

## 7. API文档

### 7.1 认证API

| 端点 | 方法 | 说明 |
|------|------|------|
| /api/auth/register | POST | 用户注册 |
| /api/auth/login | POST | 用户登录 |
| /api/auth/logout | POST | 用户登出 |
| /api/auth/me | GET | 获取当前用户信息 |

### 7.2 小说管理API

| 端点 | 方法 | 说明 |
|------|------|------|
| /api/novels | GET | 获取小说列表 |
| /api/novels | POST | 创建小说 |
| /api/novels/:id | GET | 获取小说详情 |
| /api/novels/:id | PUT | 更新小说 |
| /api/novels/:id | DELETE | 删除小说 |

### 7.3 内容生成API（Python后端）

| 端点 | 方法 | 说明 |
|------|------|------|
| /api/generate/outline | POST | 生成大纲（流式） |
| /api/generate/detailed-outline | POST | 生成细纲（流式） |
| /api/generate/chapter | POST | 生成章节（流式） |
| /api/generate/revise | POST | AI修改内容（流式） |

### 7.4 知识图谱API（Python后端）

| 端点 | 方法 | 说明 |
|------|------|------|
| /api/knowledge/graph | GET | 获取知识图谱数据 |
| /api/knowledge/characters | GET | 获取人物关系网络 |
| /api/knowledge/timeline | GET | 获取时间线 |
| /api/knowledge/search | POST | 向量检索 |

---

## 8. 配置说明

### 8.1 环境变量配置

**Node.js环境变量（.env）**

| 变量名 | 说明 | 示例 |
|--------|------|------|
| DATABASE_URL | MySQL连接字符串 | mysql://user:pass@localhost:3306/db |
| JWT_SECRET | JWT签名密钥 | your-secret-key |

**Python环境变量（python_backend/.env）**

| 变量名 | 说明 | 示例 |
|--------|------|------|
| MYSQL_HOST | MySQL主机 | localhost |
| MYSQL_PORT | MySQL端口 | 3306 |
| MYSQL_USER | MySQL用户 | root |
| MYSQL_PASSWORD | MySQL密码 | password |
| MYSQL_DATABASE | 数据库名 | ai_novel_generator |
| MILVUS_HOST | Milvus主机 | localhost |
| MILVUS_PORT | Milvus端口 | 19530 |
| NEO4J_URI | Neo4j连接URI | bolt://localhost:7687 |
| NEO4J_USER | Neo4j用户 | neo4j |
| NEO4J_PASSWORD | Neo4j密码 | password |
| OPENAI_API_KEY | OpenAI API密钥 | sk-xxx |
| OPENAI_API_BASE | OpenAI API地址 | https://api.openai.com/v1 |

### 8.2 AI模型配置

系统支持多种AI模型，可在"AI模型配置"页面进行设置：

| 提供商 | 支持的模型 | 说明 |
|--------|------------|------|
| OpenAI | gpt-4, gpt-4-turbo, gpt-3.5-turbo | 官方API |
| Anthropic | claude-3-opus, claude-3-sonnet | 官方API |
| DeepSeek | deepseek-chat, deepseek-coder | 国产模型 |
| 智谱AI | glm-4, glm-3-turbo | 国产模型 |
| Moonshot | moonshot-v1-8k, moonshot-v1-32k | 国产模型 |
| 通义千问 | qwen-turbo, qwen-plus | 阿里云 |
| Ollama | 本地模型 | 本地部署 |
| 自定义 | 任意模型 | 自定义API |

所有模型都支持自定义baseUrl，方便使用代理或私有部署。

---

## 附录

### A. 默认账户

| 用户名 | 密码 | 角色 |
|--------|------|------|
| admin | admin123 | 管理员 |

### B. 常见问题

**Q: 如何更换AI模型？**
A: 在"AI模型配置"页面添加新的模型配置，设置为默认即可。

**Q: 如何备份数据？**
A: 定期备份MySQL数据库、Milvus集合和Neo4j图数据库。

**Q: 生成内容不连贯怎么办？**
A: 确保已正确配置Milvus向量库，并在生成前同步知识库。

### C. 技术支持

如有问题，请联系技术支持或查阅项目文档。

---

*文档结束*
