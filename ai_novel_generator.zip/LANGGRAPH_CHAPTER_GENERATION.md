# LangGraph 章节生成方案

## 架构设计

```
用户点击"生成细纲/章节" 
  ↓
前端 (tRPC) → Node.js 服务器 → Python 后端 (FastAPI)
  ↓
LangGraph 工作流
  ↓
├─ 1. 检索知识 (retrieve_knowledge)
│   ├─ 向量库检索：人物、地点、物品、组织、伏笔
│   └─ 知识图谱：人物关系
│
├─ 2. 生成细纲 (generate_outline)
│   ├─ 输入：总大纲 + 前几章细纲 + 检索到的知识
│   └─ 输出：2000字细纲（前文总结、剧情发展、人物动态、场景描述、对话要点）
│
├─ 3. 生成章节 (generate_content)
│   ├─ 输入：细纲 + 前几章摘要 + 检索到的知识
│   └─ 输出：3000字章节内容
│
├─ 4. 生成摘要 (generate_summary)
│   └─ 输出：200字AI摘要
│
├─ 5. 提取知识 (extract_knowledge)
│   └─ 输出：新人物、地点、物品、组织、伏笔
│
└─ 6. 同步知识库 (sync_knowledge)
    └─ 保存到 knowledge_entries 表
```

## 文件结构

### Python 后端
```
python_backend/
├── app/
│   ├── api/
│   │   └── chapter_generation.py  # FastAPI 路由
│   └── services/
│       └── langgraph/
│           └── chapter_generation_graph.py  # LangGraph 工作流
```

### Node.js 服务器
```
server/
└── routers/
    └── chapterGeneration.ts  # tRPC 路由
```

## API 接口

### 1. 生成细纲
**POST** `/api/chapter-generation/outline`

**请求：**
```json
{
  "novel_id": 1,
  "chapter_number": 5
}
```

**响应：**
```json
{
  "success": true,
  "chapter_outline": {
    "chapter_number": 5,
    "content": "细纲内容..."
  },
  "message": "第5章细纲生成成功"
}
```

### 2. 生成章节内容
**POST** `/api/chapter-generation/content`

**请求：**
```json
{
  "novel_id": 1,
  "chapter_number": 5
}
```

**响应：**
```json
{
  "success": true,
  "chapter_id": 123,
  "content": "章节内容...",
  "summary": "AI摘要...",
  "extracted_knowledge": [
    {"type": "character", "name": "张三", "description": "..."},
    {"type": "location", "name": "月影山", "description": "..."}
  ],
  "message": "第5章生成成功"
}
```

## 工作流详解

### 1. 检索知识 (retrieve_knowledge)
```python
def retrieve_knowledge(state):
    # 构建查询文本
    query_text = f"第{chapter_number}章\n{outline}"
    
    # 向量检索
    results = milvus_client.search(query_text, top_k=10)
    
    # 分类结果
    state['characters'] = [r for r in results if r['type'] == 'character']
    state['locations'] = [r for r in results if r['type'] == 'location']
    # ...
    
    return state
```

### 2. 生成细纲 (generate_outline)
```python
def generate_chapter_outline(state):
    context = f"""
    # 总大纲
    {state['outline']}
    
    # 前几章细纲
    {previous_outlines}
    
    # 相关人物
    {characters}
    
    # 相关地点
    {locations}
    """
    
    prompt = f"{context}\n请生成第{chapter_number}章细纲..."
    response = llm.invoke(prompt)
    
    state['chapter_outline'] = response.content
    return state
```

### 3. 生成章节 (generate_content)
```python
def generate_chapter_content(state):
    context = f"""
    # 细纲
    {state['chapter_outline']}
    
    # 前几章摘要
    {previous_summaries}
    
    # 人物信息
    {characters}
    """
    
    prompt = f"{context}\n根据细纲生成章节..."
    response = llm.invoke(prompt)
    
    state['chapter_content'] = response.content
    return state
```

### 4. 提取知识 (extract_knowledge)
```python
def extract_knowledge(state):
    prompt = f"""
    从章节中提取知识（JSON格式）：
    {state['chapter_content']}
    
    返回：
    [
      {{"type": "character", "name": "...", "description": "..."}},
      {{"type": "location", "name": "...", "description": "..."}}
    ]
    """
    
    response = llm.invoke(prompt)
    state['extracted_knowledge'] = json.loads(response.content)
    return state
```

### 5. 同步知识库 (sync_knowledge)
```python
def sync_to_knowledge_base(state):
    for item in state['extracted_knowledge']:
        entry = KnowledgeEntry(
            novel_id=state['novel_id'],
            chapter_number=state['chapter_number'],
            entry_type=item['type'],
            name=item['name'],
            description=item['description']
        )
        db.add(entry)
    db.commit()
    return state
```

## 前端调用示例

```typescript
// 生成细纲
const generateOutline = trpc.chapterGeneration.generateOutline.useMutation({
  onSuccess: (data) => {
    toast.success(data.message);
  }
});

generateOutline.mutate({
  novelId: 1,
  chapterNumber: 5
});

// 生成章节
const generateContent = trpc.chapterGeneration.generateContent.useMutation({
  onSuccess: (data) => {
    toast.success(data.message);
    console.log('提取的知识:', data.extracted_knowledge);
  }
});

generateContent.mutate({
  novelId: 1,
  chapterNumber: 5
});
```

## 优势

1. **智能检索** - 自动从向量库和知识图谱检索相关知识
2. **上下文连贯** - 参考前几章细纲和摘要
3. **知识积累** - 自动提取并同步新知识
4. **流程可视** - LangGraph 提供清晰的工作流
5. **易于扩展** - 可以轻松添加新节点（如伏笔检测、风格检查等）

## 下一步

- [ ] 添加伏笔处理节点
- [ ] 集成 Neo4j 人物关系图谱
- [ ] 添加风格一致性检查
- [ ] 支持流式输出（SSE）
- [ ] 添加生成进度反馈

