# 幻写次元 - AI小说生成系统 (Python后端)

一个功能完整的AI辅助小说创作平台，使用Python FastAPI后端 + LangChain/LangGraph，集成MySQL、Milvus向量库和Neo4j知识图谱。

## 技术栈

- **后端框架**: Python 3.11+ / FastAPI
- **AI框架**: LangChain + LangGraph (最新版本)
- **数据库**: MySQL 8.0+
- **向量库**: Milvus 2.3+
- **知识图谱**: Neo4j 5.0+
- **认证**: JWT Token

## 系统要求

- Python 3.11 或更高版本
- MySQL 8.0 或更高版本
- Milvus 2.3 或更高版本 (可选，用于向量检索)
- Neo4j 5.0 或更高版本 (可选，用于知识图谱)
- OpenAI API Key 或兼容的LLM API

## 快速开始

### 1. 克隆项目

```bash
cd python_backend
```

### 2. 创建虚拟环境

```bash
python -m venv venv

# Windows
venv\Scripts\activate

# Linux/Mac
source venv/bin/activate
```

### 3. 安装依赖

```bash
pip install -r requirements.txt
```

### 4. 配置环境变量

复制环境变量模板并修改：

```bash
cp env.template .env
```

编辑 `.env` 文件，填入你的配置：

```env
# 数据库配置
DATABASE_URL=mysql+pymysql://user:password@localhost:3306/ai_novel

# JWT配置
JWT_SECRET=your-super-secret-jwt-key-change-this
JWT_ALGORITHM=HS256
JWT_EXPIRE_HOURS=24

# OpenAI配置（或兼容API）
OPENAI_API_KEY=your-openai-api-key
OPENAI_API_BASE=https://api.openai.com/v1
OPENAI_MODEL=gpt-4o

# Milvus配置（可选）
MILVUS_HOST=localhost
MILVUS_PORT=19530
MILVUS_COLLECTION_PREFIX=novel_

# Neo4j配置（可选）
NEO4J_URI=bolt://localhost:7687
NEO4J_USER=neo4j
NEO4J_PASSWORD=your-neo4j-password

# 服务器配置
HOST=0.0.0.0
PORT=8000
DEBUG=true
```

### 5. 初始化数据库

```bash
# 创建MySQL数据库
mysql -u root -p -e "CREATE DATABASE ai_novel CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;"

# 运行数据库迁移
python -c "from app.db.mysql import init_db; import asyncio; asyncio.run(init_db())"
```

### 6. 启动服务

#### 方式一：使用启动脚本（推荐）

```bash
# Windows (PowerShell)
.\start_backend.ps1

# Linux/Mac
chmod +x start_backend.sh
./start_backend.sh
```

#### 方式二：使用 Conda 环境

```bash
# 激活 conda 环境
conda activate ai_novel_generator

# 启动服务
python -m uvicorn main:app --host 0.0.0.0 --port 8001 --reload
```

#### 方式三：直接运行

```bash
# 开发模式
python main.py

# 或使用uvicorn
uvicorn main:app --host 0.0.0.0 --port 8001 --reload
```

服务将在 http://localhost:8001 启动。

> **注意**: 默认端口为 8001，确保前端配置的 `PYTHON_API_URL` 环境变量指向 `http://localhost:8001`

## API文档

启动服务后，访问以下地址查看API文档：

- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

## 项目结构

```
python_backend/
├── app/
│   ├── api/                    # API路由
│   │   ├── auth.py            # 认证API
│   │   ├── novels.py          # 小说管理API
│   │   ├── characters.py      # 人物设定API
│   │   ├── outlines.py        # 大纲生成API
│   │   ├── chapters.py        # 章节生成API
│   │   ├── knowledge.py       # 知识图谱API
│   │   ├── model_config.py    # 模型配置API
│   │   ├── history.py         # 生成历史API
│   │   └── admin.py           # 管理员API
│   ├── config/
│   │   └── settings.py        # 配置管理
│   ├── db/
│   │   ├── mysql.py           # MySQL连接
│   │   ├── milvus.py          # Milvus连接
│   │   └── neo4j.py           # Neo4j连接
│   ├── models/
│   │   ├── database.py        # 数据库模型
│   │   └── schemas.py         # Pydantic模型
│   └── services/
│       ├── auth.py            # 认证服务
│       ├── knowledge_service.py  # 知识库服务
│       ├── langchain/         # LangChain服务
│       │   ├── llm_service.py
│       │   ├── embedding_service.py
│       │   └── rag_service.py
│       └── langgraph/         # LangGraph工作流
│           └── novel_workflow.py
├── main.py                    # 应用入口
├── requirements.txt           # Python依赖
└── env.template              # 环境变量模板
```

## 核心功能

### 1. 用户系统
- 用户注册/登录（JWT认证）
- 角色管理（admin/user）
- 数据隔离（每个用户只能访问自己的数据）

### 2. 小说项目管理
- 创建/编辑/删除小说项目
- 配置小说基本信息（标题、类型、风格、简介、提示词）
- 世界观设定管理

### 3. 人物设定管理
- 创建/编辑/删除角色
- 角色信息（姓名、性格、背景、外貌、能力等）
- 自动同步到Neo4j知识图谱

### 4. 大纲生成
- 基于设定和提示词的AI大纲生成
- 流式响应，实时显示生成进度
- 大纲版本管理

### 5. 细纲生成
- 根据大纲自动生成细纲
- 每5章为一组的细纲结构
- AI修改和自定义编辑

### 6. 章节内容生成
- 基于细纲的章节内容生成
- 结合Milvus向量库检索历史内容（RAG）
- 结合Neo4j知识图谱确保一致性
- 流式输出支持

### 7. 章节审核
- 章节审核（通过/拒绝）
- 提交修改意见
- AI根据意见重新生成

### 8. 知识图谱
- 人物关系网络可视化
- 世界观结构图谱
- 时间线图谱

### 9. AI模型配置
- 支持OpenAI和自定义API
- 模型参数配置（温度、top_p等）
- 多模型切换

## Milvus配置（可选）

如果需要使用向量检索功能，请安装并配置Milvus：

```bash
# 使用Docker安装Milvus
docker run -d --name milvus-standalone \
  -p 19530:19530 \
  -p 9091:9091 \
  milvusdb/milvus:latest
```

## Neo4j配置（可选）

如果需要使用知识图谱功能，请安装并配置Neo4j：

```bash
# 使用Docker安装Neo4j
docker run -d --name neo4j \
  -p 7474:7474 -p 7687:7687 \
  -e NEO4J_AUTH=neo4j/your-password \
  neo4j:latest
```

## 生产部署

### 使用Gunicorn

```bash
pip install gunicorn

gunicorn main:app -w 4 -k uvicorn.workers.UvicornWorker -b 0.0.0.0:8000
```

### 使用Docker

```dockerfile
FROM python:3.11-slim

WORKDIR /app

COPY requirements.txt .
RUN pip install --no-cache-dir -r requirements.txt

COPY . .

CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
```

## 常见问题

### Q: 如何更换LLM模型？
A: 在AI模型配置页面添加新的模型配置，支持OpenAI兼容的API。

### Q: 向量库和知识图谱是必须的吗？
A: 不是必须的。如果不配置Milvus和Neo4j，系统会使用降级模式运行，但RAG和知识图谱功能将不可用。

### Q: 如何备份数据？
A: 定期备份MySQL数据库即可。Milvus和Neo4j的数据可以通过各自的备份工具进行备份。

## 许可证

MIT License
