#!/usr/bin/env python3
"""
测试向量同步API
"""
import requests
import json

# 测试数据
url = "http://localhost:8000/api/vector/sync"
headers = {
    "Content-Type": "application/json",
    "X-User-ID": "1",
    "X-Username": "ai"
}
data = {
    "novel_id": 1,
    "items": []
}

print("测试向量同步API...")
print(f"URL: {url}")
print(f"Headers: {headers}")
print(f"Data: {json.dumps(data, indent=2)}")
print()

try:
    response = requests.post(url, headers=headers, json=data)
    print(f"状态码: {response.status_code}")
    print(f"响应: {response.text}")

    if response.status_code == 200:
        print("\n✓ 测试成功！")
    else:
        print("\n✗ 测试失败")
except Exception as e:
    print(f"\n✗ 请求失败: {e}")

