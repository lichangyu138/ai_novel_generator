"""
Configuration module initialization
"""
from app.config.settings import get_settings, Settings

__all__ = ["get_settings", "Settings"]
