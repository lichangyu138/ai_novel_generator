"""
细纲生成 LangGraph 工作流
"""
from typing import TypedDict, List, Dict, Any
from langgraph.graph import StateGraph, END
from sqlalchemy.orm import Session
from app.db.milvus import get_milvus_client
from app.services.langchain.llm_service import get_llm_service

class ChapterOutlineState(TypedDict):
    novel_id: int
    user_id: int
    chapter_number: int
    main_outline: str  # 总大纲
    previous_outlines: List[Dict]  # 前几章细纲
    retrieved_knowledge: Dict[str, List[Dict]]  # 检索到的知识
    generated_outline: Dict[str, str]  # 生成的细纲

def retrieve_knowledge(state: ChapterOutlineState) -> ChapterOutlineState:
    """从向量库和知识图谱检索相关知识"""
    milvus = get_milvus_client()
    
    # 构建查询文本
    query_text = f"{state['main_outline']}\n前文：{state['previous_outlines'][-1]['content'] if state['previous_outlines'] else ''}"
    
    # 向量检索
    results = milvus.search_similar(
        user_id=state['user_id'],
        novel_id=state['novel_id'],
        query_text=query_text,
        top_k=10
    )
    
    # 分类知识
    knowledge = {
        'characters': [],
        'locations': [],
        'items': [],
        'organizations': []
    }
    
    for r in results:
        entry_type = r.get('entry_type', '')
        if entry_type in knowledge:
            knowledge[entry_type].append(r)
    
    state['retrieved_knowledge'] = knowledge
    return state

def generate_outline(state: ChapterOutlineState) -> ChapterOutlineState:
    """生成细纲"""
    llm = get_llm_service()
    
    # 构建提示词
    context = f"""# 小说总大纲
{state['main_outline']}

# 前几章细纲
{chr(10).join([f"第{o['chapter_number']}章：{o['content'][:200]}..." for o in state['previous_outlines'][-3:]])}

# 相关人物
{chr(10).join([f"- {c['name']}: {c['content'][:100]}" for c in state['retrieved_knowledge']['characters'][:5]])}

# 相关地点
{chr(10).join([f"- {l['name']}: {l['content'][:100]}" for l in state['retrieved_knowledge']['locations'][:3]])}

# 相关组织
{chr(10).join([f"- {o['name']}: {o['content'][:100]}" for o in state['retrieved_knowledge']['organizations'][:3]])}

# 相关道具
{chr(10).join([f"- {i['name']}: {i['content'][:100]}" for i in state['retrieved_knowledge']['items'][:3]])}
"""
    
    prompt = f"""{context}

请为第{state['chapter_number']}章生成详细细纲（约2000字），包含：
1. 前文总结（承接上文）
2. 本章剧情发展（详细情节）
3. 人物动态（角色行为和心理）
4. 场景描述（环境氛围）
5. 关键对话要点

要求：
- 与总大纲保持一致
- 自然承接前文
- 合理使用已有的人物、地点、组织、道具
- 情节紧凑，有冲突和转折
"""
    
    result = llm.generate(prompt)
    
    # 解析结果（简化版）
    state['generated_outline'] = {
        'previousSummary': result[:500],
        'plotDevelopment': result[500:1500],
        'characterDynamics': result[1500:2000],
        'sceneDescription': result[2000:2500],
        'dialoguePoints': result[2500:]
    }
    
    return state

# 创建工作流
def create_chapter_outline_graph():
    workflow = StateGraph(ChapterOutlineState)
    
    workflow.add_node("retrieve_knowledge", retrieve_knowledge)
    workflow.add_node("generate_outline", generate_outline)
    
    workflow.set_entry_point("retrieve_knowledge")
    workflow.add_edge("retrieve_knowledge", "generate_outline")
    workflow.add_edge("generate_outline", END)
    
    return workflow.compile()

# 执行函数
async def generate_chapter_outline(
    novel_id: int,
    user_id: int,
    chapter_number: int,
    main_outline: str,
    previous_outlines: List[Dict],
    db: Session
) -> Dict[str, str]:
    """生成细纲"""
    graph = create_chapter_outline_graph()
    
    result = await graph.ainvoke({
        'novel_id': novel_id,
        'user_id': user_id,
        'chapter_number': chapter_number,
        'main_outline': main_outline,
        'previous_outlines': previous_outlines,
        'retrieved_knowledge': {},
        'generated_outline': {}
    })
    
    return result['generated_outline']

