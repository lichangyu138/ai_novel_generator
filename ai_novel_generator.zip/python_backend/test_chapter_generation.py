"""
测试 LangGraph 章节生成工作流
"""
import sys
sys.path.append('.')

from app.services.langgraph.chapter_generation_graph import chapter_generation_graph


def test_chapter_generation():
    """测试章节生成流程"""
    
    # 模拟初始状态
    initial_state = {
        "novel_id": 1,
        "user_id": 1,
        "chapter_number": 5,
        "outline": "这是一个修仙小说，主角张三在月影宗修炼...",
        "previous_outlines": [
            {
                "chapter_number": 4,
                "plot_development": "张三突破筑基期..."
            }
        ],
        "previous_summaries": [
            "第4章：张三在月影山闭关，成功突破筑基期。"
        ],
        "characters": [],
        "locations": [],
        "items": [],
        "organizations": [],
        "foreshadowing": [],
        "character_relations": [],
        "chapter_outline": None,
        "chapter_content": None,
        "chapter_summary": None,
        "extracted_knowledge": None,
        "new_foreshadowing": None,
        "error": None
    }
    
    print("=" * 70)
    print("开始测试章节生成工作流")
    print("=" * 70)
    
    try:
        # 执行工作流
        result = chapter_generation_graph.invoke(initial_state)
        
        print("\n✓ 工作流执行成功！\n")
        
        # 打印结果
        if result.get('chapter_outline'):
            print("【细纲】")
            print(result['chapter_outline'].get('content', '')[:200] + "...")
            print()
        
        if result.get('chapter_content'):
            print("【章节内容】")
            print(result['chapter_content'][:200] + "...")
            print()
        
        if result.get('chapter_summary'):
            print("【AI摘要】")
            print(result['chapter_summary'])
            print()
        
        if result.get('extracted_knowledge'):
            print("【提取的知识】")
            for item in result['extracted_knowledge'][:5]:
                print(f"  - {item['type']}: {item['name']}")
            print()
        
        if result.get('error'):
            print("【错误】")
            print(result['error'])
            print()
        
        print("=" * 70)
        print("测试完成")
        print("=" * 70)
        
    except Exception as e:
        print(f"\n✗ 工作流执行失败: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    test_chapter_generation()

