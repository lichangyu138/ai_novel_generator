#!/usr/bin/env python3
"""
测试用户登录功能
"""
import pymysql
from dotenv import load_dotenv
import os
from passlib.context import CryptContext

load_dotenv()

# 数据库配置
MYSQL_HOST = os.getenv('MYSQL_HOST', '10.8.6.45')
MYSQL_PORT = int(os.getenv('MYSQL_PORT', 13306))
MYSQL_USER = os.getenv('MYSQL_USER', 'root')
MYSQL_PASSWORD = os.getenv('MYSQL_PASSWORD', '4BTFesFsCtjAWX5D')
MYSQL_DATABASE = os.getenv('MYSQL_DATABASE', 'ai_novel_generator')

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def test_login():
    """测试登录"""
    print("=" * 70)
    print("测试用户登录功能")
    print("=" * 70)
    print()
    
    try:
        conn = pymysql.connect(
            host=MYSQL_HOST,
            port=MYSQL_PORT,
            user=MYSQL_USER,
            password=MYSQL_PASSWORD,
            database=MYSQL_DATABASE,
            charset='utf8mb4'
        )
        cursor = conn.cursor()
        print("[OK] 数据库连接成功")
        print()
    except Exception as e:
        print(f"[ERROR] 数据库连接失败: {e}")
        return
    
    # 检查管理员账户
    print("1. 检查管理员账户...")
    cursor.execute("SELECT id, username, email, password_hash, role, is_active FROM users WHERE username = 'admin'")
    admin = cursor.fetchone()
    
    if admin:
        admin_id, username, email, password_hash, role, is_active = admin
        print(f"   [OK] 管理员账户存在")
        print(f"   ID: {admin_id}")
        print(f"   用户名: {username}")
        print(f"   邮箱: {email}")
        print(f"   角色: {role}")
        print(f"   是否激活: {is_active}")
        print(f"   密码哈希: {password_hash[:20]}..." if password_hash else "   [WARN] 密码哈希为空")
        print()
        
        # 测试密码验证
        print("2. 测试密码验证...")
        test_password = "admin123"
        if password_hash:
            try:
                is_valid = pwd_context.verify(test_password, password_hash)
                if is_valid:
                    print(f"   [OK] 密码验证成功 (admin123)")
                else:
                    print(f"   [ERROR] 密码验证失败")
                    print(f"   正在重置密码...")
                    new_hash = pwd_context.hash(test_password)
                    cursor.execute(
                        "UPDATE users SET password_hash = %s WHERE id = %s",
                        (new_hash, admin_id)
                    )
                    conn.commit()
                    print(f"   [OK] 密码已重置为 admin123")
            except Exception as e:
                print(f"   [ERROR] 密码验证出错: {e}")
        else:
            print(f"   [WARN] 密码哈希为空，正在设置密码...")
            new_hash = pwd_context.hash(test_password)
            cursor.execute(
                "UPDATE users SET password_hash = %s WHERE id = %s",
                (new_hash, admin_id)
            )
            conn.commit()
            print(f"   [OK] 密码已设置为 admin123")
    else:
        print("   [WARN] 管理员账户不存在，正在创建...")
        password_hash = pwd_context.hash("admin123")
        cursor.execute("""
            INSERT INTO users (username, email, password_hash, role, is_active, created_at, updated_at)
            VALUES ('admin', 'admin@example.com', %s, 'admin', TRUE, NOW(), NOW())
        """, (password_hash,))
        conn.commit()
        print("   [OK] 管理员账户已创建")
        print("   用户名: admin")
        print("   密码: admin123")
    
    # 列出所有用户
    print()
    print("3. 所有用户列表...")
    cursor.execute("SELECT id, username, email, role, is_active FROM users")
    users = cursor.fetchall()
    print(f"   共有 {len(users)} 个用户:")
    for user in users:
        print(f"   - ID: {user[0]}, 用户名: {user[1]}, 邮箱: {user[2]}, 角色: {user[3]}, 激活: {user[4]}")
    
    cursor.close()
    conn.close()
    
    print()
    print("=" * 70)
    print("测试完成")
    print("=" * 70)
    print("现在可以使用以下账户登录:")
    print("  用户名: admin")
    print("  密码: admin123")
    print()

if __name__ == "__main__":
    test_login()

