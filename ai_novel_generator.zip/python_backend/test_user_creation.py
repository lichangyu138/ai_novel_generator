#!/usr/bin/env python3
"""
测试用户创建功能
"""
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from dotenv import load_dotenv
load_dotenv()

from app.db.mysql import SessionLocal, init_db
from app.models.database import User, UserRole
from app.services.auth import register_user, get_password_hash
from sqlalchemy.exc import IntegrityError

def test_user_creation():
    """测试用户创建"""
    print("=" * 50)
    print("测试用户创建功能")
    print("=" * 50)
    print()
    
    # 初始化数据库
    try:
        init_db()
        print("[OK] 数据库连接成功")
    except Exception as e:
        print(f"[ERROR] 数据库连接失败: {e}")
        return
    
    db = SessionLocal()
    try:
        # 测试创建用户
        test_username = "test_user_" + str(int(__import__('time').time()))
        test_email = f"{test_username}@test.com"
        test_password = "test123456"
        
        print(f"尝试创建用户:")
        print(f"  用户名: {test_username}")
        print(f"  邮箱: {test_email}")
        print()
        
        try:
            user = register_user(
                db=db,
                username=test_username,
                email=test_email,
                password=test_password
            )
            print(f"[OK] 用户创建成功!")
            print(f"  用户ID: {user.id}")
            print(f"  用户名: {user.username}")
            print(f"  邮箱: {user.email}")
            print(f"  角色: {user.role}")
            print(f"  是否激活: {user.is_active}")
            
            # 清理测试用户
            db.delete(user)
            db.commit()
            print()
            print("[OK] 测试用户已清理")
            
        except Exception as e:
            print(f"[ERROR] 用户创建失败: {e}")
            print(f"  错误类型: {type(e).__name__}")
            import traceback
            traceback.print_exc()
            
    finally:
        db.close()
    
    print()
    print("=" * 50)
    print("测试完成")
    print("=" * 50)

if __name__ == "__main__":
    test_user_creation()

