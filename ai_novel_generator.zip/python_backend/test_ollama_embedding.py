#!/usr/bin/env python3
"""
测试 Ollama Embedding API
"""
import requests
import json

# Ollama API 配置
base_url = "http://192.168.7.102:11434"
model = "bge-large:335m"

# 测试文本
test_text = "这是一个测试文本"

print(f"测试 Ollama Embedding API")
print(f"Base URL: {base_url}")
print(f"Model: {model}")
print(f"Text: {test_text}")
print()

# 测试 /api/embeddings 端点
url = f"{base_url}/api/embeddings"
payload = {
    "model": model,
    "prompt": test_text
}

print(f"请求 URL: {url}")
print(f"Payload: {json.dumps(payload, indent=2, ensure_ascii=False)}")
print()

try:
    response = requests.post(url, json=payload, timeout=10)
    print(f"状态码: {response.status_code}")
    print(f"响应: {response.text[:200]}")

    if response.status_code == 200:
        data = response.json()
        if 'embedding' in data:
            print(f"\n✓ 成功！Embedding 维度: {len(data['embedding'])}")
        else:
            print(f"\n✗ 响应中没有 embedding 字段")
    else:
        print(f"\n✗ 请求失败")
except Exception as e:
    print(f"\n✗ 错误: {e}")

