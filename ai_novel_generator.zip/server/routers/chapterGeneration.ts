/**
 * Chapter Generation tRPC Router (LangGraph)
 */
import { z } from 'zod';
import { protectedProcedure, router } from '../_core/trpc';
import { COOKIE_NAME } from '@shared/const';

const PYTHON_API_URL = process.env.PYTHON_API_URL || 'http://localhost:8000';

export const chapterGenerationRouter = router({
  // 生成细纲
  generateOutline: protectedProcedure
    .input(z.object({
      novelId: z.number(),
      chapterNumber: z.number(),
    }))
    .mutation(async ({ input, ctx }) => {
      // 从 cookie 中获取 token
      const cookies = ctx.req.headers.cookie?.split(';').reduce((acc, cookie) => {
        const [key, value] = cookie.trim().split('=');
        acc[key] = value;
        return acc;
      }, {} as Record<string, string>) || {};

      const token = cookies[COOKIE_NAME];

      const response = await fetch(`${PYTHON_API_URL}/api/chapter-generation/outline`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          novel_id: input.novelId,
          chapter_number: input.chapterNumber,
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.detail || '细纲生成失败');
      }

      return await response.json();
    }),

  // 生成章节内容
  generateContent: protectedProcedure
    .input(z.object({
      novelId: z.number(),
      chapterNumber: z.number(),
      targetWordCount: z.number().default(5000),
    }))
    .mutation(async ({ input, ctx }) => {
      // 从 cookie 中获取 token
      const cookies = ctx.req.headers.cookie?.split(';').reduce((acc, cookie) => {
        const [key, value] = cookie.trim().split('=');
        acc[key] = value;
        return acc;
      }, {} as Record<string, string>) || {};

      const token = cookies[COOKIE_NAME];

      const response = await fetch(`${PYTHON_API_URL}/api/chapter-generation/content`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`,
        },
        body: JSON.stringify({
          novel_id: input.novelId,
          chapter_number: input.chapterNumber,
          target_word_count: input.targetWordCount,
        }),
      });

      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.detail || '章节生成失败');
      }

      return await response.json();
    }),
});

