# 知识库系统重构实施总结

## 概述
成功实现了完整的知识库系统，包括自动提取、智能去重、选择性同步和智能检索功能。

## 已完成的功能

### 1. 基础重命名 ✅
- 将"知识图谱"重命名为"知识库"
- 更新所有相关页面、导航和文案
- 图标从 Network 改为 Database

### 2. 世界观管理整合 ✅
- 在世界观页面添加"人物设定"和"人物关系"Tab
- 实现完整的人物CRUD功能
- 实现人物关系网络可视化（D3.js力导向图）
- 移除独立的人物设定页面和路由

### 3. 知识库自动提取 ✅
**文件：** `server/services/knowledgeExtractor.ts`

**功能：**
- 章节生成/更新时自动提取实体
- 使用Claude AI识别：人物、地点、物品、事件、组织
- 自动保存到知识库，标记为"自动提取"
- 记录来源章节

**集成点：**
- `server/routers.ts` - chapters.create
- `server/routers.ts` - chapters.update

### 4. 向量去重和智能合并 ✅
**文件：** `server/services/vectorDeduplicator.ts`

**功能：**
- 使用余弦相似度检测重复条目（阈值85%）
- 简单的文本特征提取（生产环境建议使用专业embedding模型）
- AI智能合并重复内容，保留所有独特信息

**算法：**
```typescript
similarity = cosineSimilarity(embedding1, embedding2)
if (similarity >= 0.85) {
  mergedContent = await AI.merge(content1, content2)
}
```

### 5. 选择性同步到世界观 ✅
**API：** `knowledge.syncToWorldbuilding`

**流程：**
1. 用户在知识库中点击"同步"按钮
2. 系统使用向量相似度检测是否已存在
3. 如果存在：AI智能合并内容
4. 如果不存在：创建新的世界观条目
5. 标记为"手动维护"（isAutoExtracted = 0）

**前端：**
- 自动提取的条目显示"同步"按钮
- 显示"自动提取"标签
- 显示来源章节

### 6. 智能知识检索 ✅
**文件：** `server/services/knowledgeRetriever.ts`

**功能：**
- 根据章节大纲检索相关知识
- 使用向量相似度排序（阈值30%）
- 按类型分组：人物、地点、物品、事件、组织
- 限制数量：人物10个、事件10个、其他5个

**API：** `knowledge.retrieveContext`

**使用方式：**
```typescript
const { formatted } = await trpc.knowledge.retrieveContext.query({
  novelId,
  chapterNumber,
  outlineContent
});
// formatted 可直接添加到生成prompt中
```

## 数据流程

### 章节生成流程
```
1. 用户生成章节
   ↓
2. 章节内容保存到数据库
   ↓
3. KnowledgeExtractor 自动提取实体
   ↓
4. 保存到知识库（isAutoExtracted = 1）
   ↓
5. 用户可选择同步到世界观
   ↓
6. VectorDeduplicator 检测重复
   ↓
7. 智能合并或创建新条目（isAutoExtracted = 0）
```

### 章节生成时检索流程
```
1. 准备生成章节
   ↓
2. 调用 knowledge.retrieveContext
   ↓
3. KnowledgeRetriever 检索相关知识
   ↓
4. 格式化为prompt上下文
   ↓
5. 添加到生成请求中
   ↓
6. AI使用知识库信息生成内容
```

## 数据库字段

### knowledgeEntries 表
- `id`: 主键
- `novelId`: 小说ID
- `userId`: 用户ID
- `type`: 类型（character/location/item/event/organization）
- `name`: 名称
- `description`: 描述
- `sourceChapterId`: 来源章节ID
- `isAutoExtracted`: 是否自动提取（1=是，0=否）
- `metadata`: JSON元数据

## API端点

### 知识库相关
- `knowledge.list` - 列出知识条目
- `knowledge.create` - 创建条目
- `knowledge.update` - 更新条目
- `knowledge.delete` - 删除条目
- `knowledge.retrieveContext` - 检索上下文（新增）
- `knowledge.syncToWorldbuilding` - 同步到世界观（新增）

### 章节相关
- `chapters.create` - 创建章节（已集成自动提取）
- `chapters.update` - 更新章节（已集成自动提取）

## 前端组件

### Knowledge.tsx
- 显示知识库条目列表
- 按类型筛选
- 显示"自动提取"标签
- 显示来源章节
- "同步到世界观"按钮（仅自动提取的条目）

### Worldbuilding.tsx
- 6个Tab：人物设定、人物关系、地点、物品、组织、时间线
- 人物关系网络可视化
- 完整的CRUD功能

## 技术栈

- **前端：** React + TypeScript + tRPC
- **后端：** Node.js + TypeScript + tRPC
- **AI：** Claude 3.5 Sonnet (Anthropic)
- **可视化：** D3.js (力导向图)
- **向量相似度：** 余弦相似度算法

## 待优化项

1. **向量Embedding：** 当前使用简单的文本特征提取，建议集成专业embedding模型（如OpenAI Embeddings或本地模型）

2. **Milvus集成：** 当前向量计算在内存中，建议集成Milvus向量数据库以提升性能

3. **批量处理：** 对于大量章节，建议添加批量提取和同步功能

4. **缓存机制：** 添加embedding缓存以减少重复计算

5. **用户反馈：** 添加用户对提取结果的反馈和修正机制

## 使用说明

### 对于用户
1. 正常生成章节，系统会自动提取知识
2. 在"知识库"页面查看自动提取的内容
3. 点击"同步"按钮将有用的条目同步到世界观
4. 在"世界观管理"中手动维护和完善信息

### 对于开发者
1. 章节生成时会自动调用 `knowledgeExtractor`
2. 可通过 `knowledge.retrieveContext` 获取相关知识
3. 将返回的 `formatted` 字符串添加到生成prompt中
4. 系统会自动处理去重和合并

## 总结

成功实现了一个完整的智能知识库系统，实现了：
- ✅ 自动提取：AI自动识别章节中的实体
- ✅ 智能去重：向量相似度检测重复
- ✅ 智能合并：AI合并重复内容
- ✅ 选择性同步：用户控制同步到世界观
- ✅ 智能检索：生成时自动检索相关知识
- ✅ 双向管理：知识库（自动）+ 世界观（手动）

系统现在能够自动维护一个不断增长的知识库，同时允许用户精细控制世界观设定。

