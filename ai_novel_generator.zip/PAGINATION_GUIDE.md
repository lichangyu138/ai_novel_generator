# 分页和批量删除实施指南

## 已完成
1. ✅ 创建 PaginatedList 通用组件
2. ✅ 添加所有批量删除函数
3. ✅ 人物设定Tab已集成

## 待更新的Tab

### 地点场景 (locations)
```tsx
<PaginatedList
  items={filteredLocations}
  pageSize={12}
  getItemId={(loc) => loc.id}
  onBatchDelete={batchDeleteLocations}
  renderItem={(location, isSelected, onToggle) => (
    <Card key={location.id}>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Checkbox checked={isSelected} onCheckedChange={onToggle} />
          {/* 原有内容 */}
        </div>
      </CardHeader>
      {/* 其他内容保持不变 */}
    </Card>
  )}
/>
```

### 物品道具 (items)
```tsx
<PaginatedList
  items={filteredItems}
  pageSize={12}
  getItemId={(item) => item.id}
  onBatchDelete={batchDeleteItems}
  renderItem={(item, isSelected, onToggle) => (
    <Card key={item.id}>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Checkbox checked={isSelected} onCheckedChange={onToggle} />
          {/* 原有内容 */}
        </div>
      </CardHeader>
      {/* 其他内容保持不变 */}
    </Card>
  )}
/>
```

### 组织势力 (organizations)
```tsx
<PaginatedList
  items={filteredOrganizations}
  pageSize={12}
  getItemId={(org) => org.id}
  onBatchDelete={batchDeleteOrganizations}
  renderItem={(org, isSelected, onToggle) => (
    <Card key={org.id}>
      <CardHeader>
        <div className="flex items-center gap-2">
          <Checkbox checked={isSelected} onCheckedChange={onToggle} />
          {/* 原有内容 */}
        </div>
      </CardHeader>
      {/* 其他内容保持不变 */}
    </Card>
  )}
/>
```

### 时间线 (timeline)
时间线使用特殊的甘特图布局，建议单独处理分页

## 知识库页面
Knowledge.tsx 也需要添加分页和批量删除功能

